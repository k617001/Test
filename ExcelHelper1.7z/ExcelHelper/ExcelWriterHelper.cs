﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NPOI.SS.UserModel;
using System.IO;
using NPOI.HSSF.UserModel;
using NPOI.XSSF.UserModel;

namespace CommonUtil.Helper.ExcelHelper
{
    public class ExcelWriterHelper : ExcelReaderHelper
    {
        /// <summary>
        /// 寫入cell值-字串，自動換下一個cell
        /// </summary>
        /// <returns></returns>
        public ICell SetCellValue(string value)
        {
            ICell cell = GetCell();
            cell.SetCellValue(value);
            this.cellIndex++;
            return cell;
        }


        /// <summary>
        /// 寫入cell值-日期，自動換下一個cell
        /// </summary>
        /// <returns></returns>
        public ICell SetCellValue(DateTime value)
        {
            ICell cell = GetCell();
            cell.SetCellValue(value);
            this.cellIndex++;
            return cell;
        }


        /// <summary>
        /// 寫入cell值-數值，自動換下一個cell
        /// </summary>
        /// <returns></returns>
        public ICell SetCellValue(double value)
        {
            ICell cell = GetCell();
            cell.SetCellValue(value);
            this.cellIndex++;
            return cell;
        }

        /// <summary>
        /// 寫入row值-字串，自動換下一個row的cell
        /// </summary>
        /// <returns></returns>
        public ICell SetRowValue(string value)
        {
            ICell cell = GetCell();
            cell.SetCellValue(value);
            this.rowIndex++;
            return cell;
        }


        /// <summary>
        /// 寫入row值-日期，自動換下一個row的cell
        /// </summary>
        /// <returns></returns>
        public ICell SetRowValue(DateTime value)
        {
            ICell cell = GetCell();
            cell.SetCellValue(value);
            this.rowIndex++;
            return cell;
        }


        /// <summary>
        /// 寫入row值-數值，自動換下一個row的cell
        /// </summary>
        /// <returns></returns>
        public ICell SetRowValue(double value)
        {
            ICell cell = GetCell();
            cell.SetCellValue(value);
            this.rowIndex++;
            return cell;
        }

        public void SaveTo(string path)
        {
            using (FileStream file = new FileStream(path, FileMode.Create))
            {
                base.wk.Write(file);
            }
        }

        /// <summary>
        /// 寫到memory stream
        /// </summary>
        /// <returns></returns>
        public MemoryStream SaveToStream()
        {
            MemoryStream memoryStream = null;

            using (MemoryStream stream = new MemoryStream())
            {
                base.wk.Write(stream);
                memoryStream = new MemoryStream(stream.ToArray());
            }

            return memoryStream;
        }
    }
}
