﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Encog.ML.Data;
using Encog.Neural.Networks;
using Encog.Neural.Networks.Layers;
using Encog.Engine.Network.Activation;
using Encog.ML.Data.Basic;
using Encog.ML.Train;
using Encog.Neural.Networks.Training.Propagation.Resilient;
using Encog.Neural.NEAT;
using Encog.Neural.Networks.Training;
using Encog.ML.EA.Train;
using Encog.Util.Simple;
using Encog.Neural.Networks.Training.Propagation.Back;
using Encog.Neural.Networks.Training.Propagation;

namespace ConsoleTest.DataBySplitFile.Encog
{
    public class AddTest
    {

        public static int INPUT_NUM = 5000;

        public static double[][] Input = new double[INPUT_NUM][];
        public static double[][] Ideal = new double[INPUT_NUM][];

        public int div = 0;


        public void Action()
        {
            SetData3();
            
            double[][] input = Input;
            double[][] ideal = Ideal;

            Execute(input, ideal);
        }

        private void SetData3()
        {
            for (int i = 0; i < INPUT_NUM; i++)
            {
                double input1 = 0.1;
                double ideal = input1 + input1;

                Input[i] = new double[] { input1, input1 };
                Ideal[i] = new double[] { ideal };
            }
        }

        private void SetData2()
        {
            for (int i = 0; i < INPUT_NUM; i++)
            {
                double input1 = strAddZero(i + 1);
                double ideal = input1 + input1;

                Input[i] = new double[] { input1, input1 };
                Ideal[i] = new double[] { ideal };
            }
        }

        private double strAddZero(int value)
        {
            return Convert.ToDouble("0." + value);
        }

        private void SetData()
        {
            int MinValue = 1;
            int MaxValue = INPUT_NUM;

            this.div = Convert.ToInt32("1".PadRight((MaxValue*10).ToString().Length, '0'));

            Random rnd = new Random();

            for (int i = 0; i < INPUT_NUM; i++)
            {
                int ideal = rnd.Next(MinValue, MaxValue);
                double input1 = (double)rnd.Next(MinValue, ideal);
                double input2 = ideal - input1;

                Input[i] = new double[] { input1 / div, input2 / div };
                Ideal[i] = new double[] { (double)ideal / div };
            }
        }

        /// <summary>
        /// Program entry point.
        /// </summary>
        /// <param name="app">Holds arguments and other info.</param>
        public void Execute(double[][] input, double[][] ideal)
        {
            // create a neural network, without using a factory
            BasicNetwork network = new BasicNetwork();
            network.AddLayer(new BasicLayer(null, true, 2));
            network.AddLayer(new BasicLayer(new ActivationSigmoid(), true, 4));
            network.AddLayer(new BasicLayer(new ActivationSigmoid(), false, 1));
            network.Structure.FinalizeStructure();
            network.Reset();

            // create training data
            IMLDataSet trainingSet = new BasicMLDataSet(input, ideal);

            // train the neural network using online (batch=1)
            Propagation train = new Backpropagation(network, trainingSet, 0.1, 0.7);
            train.BatchSize = 1;

            int epoch = 1;
            double min = 9999.0;

            do
            {
                if (train.Error > 0 && min > train.Error)
                {
                    min = train.Error;
                }

                train.Iteration();
                Console.WriteLine(@"Epoch #" + epoch + @" Error:" + train.Error + @" Min:" + min);
                epoch++;
            } while (train.Error > 0.01);

            // test the neural network
            Console.WriteLine(@"Neural Network Results:");
            int i = 0;
            foreach (IMLDataPair pair in trainingSet)
            {
                i++;
                IMLData output = network.Compute(pair.Input);
                double outputActual = output[0] ;
                double idealVal = pair.Ideal[0] ;
                double sub = idealVal - outputActual;

                Console.WriteLine(
                        i + 
                        @"." + pair.Input[0]  + "+" + pair.Input[1]  + "=" + idealVal + @", "
                        + @"Actual=" + outputActual + @", "
                        + @"sub=" + sub
                        );
            }
        }
    }
}
