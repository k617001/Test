﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataBySplitFile.Common.CSVLoad;
using Newtonsoft.Json;
using System.IO;
using ConsoleTest.DataBySplitFile.Common;

namespace ConsoleTest.DataBySplitFile
{
    /// <summary>
    /// 把日漲跌的csv資料，變成js檔，畫成highchart
    /// </summary>
    public class DayLimitHighLowReportData
    {
        string filePath = RunAction.TARGET_DIR + @"analysis\HighLowLimitDay";
        string targetPath = RunAction.HTML_REPORT_DIR + @"Data\";
        string jsName = "MaxMinLimitValueSumData_Day";

        StringBuilder content = new StringBuilder();

        MaxMinLimitObjGroupForChart groupChart = new MaxMinLimitObjGroupForChart();

        public void Action()
        {
            string[] paths = Directory.GetFiles(filePath);

            foreach (string path in paths) 
            {
                this.LoadDayFile(path);
            }
            //寫入至資料js檔案
            ComUtil.CreateDataJsFile(jsName, groupChart.Day, targetPath);

        }

        private void LoadDayFile(string path)
        {
            Console.WriteLine(path);
            CSVLoadHelper.LoadCsv(path, (row, convert) =>
            {
                SetGroup(convert, "yyyy-MM-dd", groupChart.Day);
            });
        }

        /// <summary>
        /// 設定群組
        /// </summary>
        /// <param name="convert"></param>
        /// <param name="dateFormat"></param>
        /// <param name="group"></param>
        private void SetGroup(
            CSVLoadConvert convert,
            string dateFormat,
            Dictionary<string, MaxMinLimitObjForChart> groupMap
            )
        {
            string date = convert.Get<string>("date");
            string time = convert.Get<string>("time");
            string dt = date + " " + (time.Length > 5 ? time : time + ":00");
            DateTime dateTime = Convert.ToDateTime(dt);
            string groupName = dateTime.ToString(dateFormat);

            MaxMinLimitObjForChart chartData = null;
            if (!groupMap.ContainsKey(groupName))
            {
                groupMap.Add(groupName, new MaxMinLimitObjForChart());
            }
            chartData = groupMap[groupName];

            chartData.Date.Add(dateTime.ToString("HH:mm"));
            chartData.Close.Add(convert.Get<int>("Close"));
            chartData.Volume.Add(convert.Get<int>("Volume"));
        }


        public class MaxMinLimitObjGroupForChart
        {
            public MaxMinLimitObjGroupForChart()
            {
                Day = new Dictionary<string, MaxMinLimitObjForChart>();
            }

            public Dictionary<string, MaxMinLimitObjForChart> Day { set; get; }
        }

        public class MaxMinLimitObjForChart
        {
            public MaxMinLimitObjForChart()
            {
                Date = new List<string>();
                Close = new List<int>();
                Volume = new List<int>();
            }

            public List<string> Date { set; get; }

            public List<int> Close { set; get; }

            public List<int> Volume { set; get; }
        }
    }
}
