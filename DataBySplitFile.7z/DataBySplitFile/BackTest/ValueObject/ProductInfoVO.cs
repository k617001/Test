﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleTest.DataBySplitFile.BackTest.ValueObject
{
    public class ProductInfoVO
    {
        /// <summary>
        /// 產品Id
        /// </summary>
        public string NameId { set; get; }

        /// <summary>
        /// 產品簡稱
        /// </summary>
        public string NickName { set; get; }

        /// <summary>
        /// 產品名稱
        /// </summary>
        public string Name { set; get; }

        /// <summary>
        /// 手續費
        /// </summary>
        public int Fee { set; get; }

        /// <summary>
        /// 手續費比例
        /// </summary>
        public double FeePercent { set; get; }

        /// <summary>
        /// 一點多少錢
        /// </summary>
        public int PointMoney { set; get; }

        /// <summary>
        /// 停損點
        /// </summary>
        public int StopLosePoint { set; get; }

        /// <summary>
        /// 取得產品路徑
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        public string GetProductPath(string path)
        {
            return path + this.NameId + @"\";
        }
    }
}
