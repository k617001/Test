﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleTest.DataBySplitFile.BackTest.Entity
{
    public class DailyEntity
    {
        public DateTime DateTime { set; get; }
        public int Open { set; get; }
        public int High { set; get; }
        public int Low { set; get; }
        public int Close { set; get; }
        public int Volume { set; get; }
    }
}
