﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleTest.DataBySplitFile.BackTest.Entity
{
    public class DailyAverageEntity
    {

        public DateTime DateTime { set; get; }
        public int Close { set; get; }
        public int Average { set; get; }
        public int Unit { set; get; }
    }
}
