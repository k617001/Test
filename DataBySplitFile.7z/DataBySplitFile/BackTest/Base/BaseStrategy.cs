﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ConsoleTest.DataBySplitFile.BackTest.ValueObject;
using ConsoleTest.DataBySplitFile.BackTest.Entity;
using ConsoleTest.DataBySplitFile.BackTest.MainData;

namespace ConsoleTest.DataBySplitFile.BackTest.Base
{
    /// <summary>
    /// 使用平均線的策略
    /// </summary>
	public abstract class BaseAvgStrategy
    {
        protected ProductInfoVO productVO = null;
        public BaseAvgStrategy(
            ProductInfoVO productVO,
            AvgData avgData,
            BuyData buyData,
            SellData sellData
            )
        {
            this.productVO = productVO;

            this.BuyData = buyData;
            this.SellData = sellData;
            this.AvgData = avgData;
        }
        /// <summary>
        /// 設定買的物件
        /// </summary>
        protected BuyData BuyData { set; get; }

        /// <summary>
        /// 設定賣的物件
        /// </summary>
        protected SellData SellData { set; get; }

        /// <summary>
        /// 設定均線物件
        /// </summary>
        protected AvgData AvgData { set; get; }



        /// <summary>
        /// 清空資料，測試用
        /// </summary>
        public void Clear()
        {
            this.BuyData.DeleteAll();
            this.SellData.DeleteAll();
        }

        /// <summary>
        /// 買
        /// </summary>
        /// <param name="data"></param>
        /// <param name="type"></param>
        protected void Buy(
            NowDataVO data, 
            int type, 
            DailyAverageEntity weekAvg, 
            DailyAverageEntity beforeClose)
        {
            BuyVO buyData = new BuyVO()
            {
                BackTestId = Guid.NewGuid(),
                Point = data.Close,
                Date = data.Date,
                Type = type,
                StopLosePointMulit = data.Close - this.productVO.StopLosePoint,
                StopLosePointEmpty = data.Close + this.productVO.StopLosePoint,
                ProductInfoVO = this.productVO,
                Selled = "N",

                BeforePoint = beforeClose.Close,
                AvePoint = weekAvg.Average,
            };

            this.BuyData.Insert(buyData);
        }

        /// <summary>
        /// 賣
        /// </summary>
        /// <param name="nowData"></param>
        /// <param name="ownData"></param>
        /// <param name="weekAvg"></param>
        /// <param name="beforeClose"></param>
        protected void Sell(
            NowDataVO nowData, 
            List<BuyVO> ownData, 
            DailyAverageEntity weekAvg, 
            DailyAverageEntity beforeClose)
        {
            //更新買的狀態
            this.BuyData.UpdateSelled(ownData);


            SellVO sellVO = new SellVO()
            {
                ProductInfoVO = this.productVO,
                SellDate = nowData.Date,
                BuyVOs = ownData,
                Point = nowData.Close,
                Volume = nowData.Volume,
            };

            this.SellData.Insert(sellVO);

            ownData.Clear();
        }
	}
}
