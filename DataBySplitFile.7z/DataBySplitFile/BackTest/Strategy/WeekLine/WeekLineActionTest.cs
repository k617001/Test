﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ConsoleTest.DataBySplitFile.BackTest.ValueObject;
using ConsoleTest.DataBySplitFile.BackTest.WeekLine.WeekLineAction;
using ConsoleTest.DataBySplitFile.BackTest.Strategy.WeekLine.Data;
using ConsoleTest.DataBySplitFile.BackTest.Entity;
using System.IO;
using ConsoleTest.DataBySplitFile.BackTest.Strategy.WeekLine.Batch;

namespace ConsoleTest.DataBySplitFile.BackTest.Strategy.WeekLine
{
    public class WeekLineActionTest
    {


        ProductInfoVO productVO = new ProductInfoVO()
        {
            NameId = "TX",
            NickName = "TX",
            Name = "TX",
            Fee = 100,
            PointMoney = 50,
            StopLosePoint = 20, //小於n點賣出
        };

        public void Action()
        {
            int day = 5;
            //轉檔
            //new ToAvgCSVBatchAction().Action();
            //new WeekLineReportData().Action();

            //策略設定(週線)
            WeekLineAction action = new WeekLineAction(
                productVO,
                new AvgDayData(day),
                new BuyDayData(productVO),
                new SellDayData(productVO)
                );
            action.Clear();
            
            /*
            DayData dayData = new DayData();
            dayData.FindDayAction("2014_01", entity =>
            {
                NowDataVO nowData = new NowDataVO()
                {
                    Date = entity.DateTime,
                    Close = entity.Close
                };
                action.StrategyAction(nowData);
            });
            */

            /*
            NowDataVO nowData = new NowDataVO()
            {
                Date = new DateTime(2015, 1, 20),
                Close = 9261
            };
            action.Test(nowData);
            */
            //查詢要測試的資料

            AvgDayData dataObj = new AvgDayData(day);
            List<DailyAverageEntity> dataList = dataObj
                                                .FindAll(null)
                                                .Where(w => w.DateTime.Year == 2008)
                                                .ToList();

            foreach (DailyAverageEntity entity in dataList)
            {
                NowDataVO nowData = new NowDataVO()
                {
                    Date = entity.DateTime,
                    Close = entity.Close
                };
                action.StrategyAction(nowData);
            }
            
        }
    }
}
