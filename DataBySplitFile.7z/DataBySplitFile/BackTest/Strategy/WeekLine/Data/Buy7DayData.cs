﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CommonUtil.Helper.CSVLoad.Plus;
using ConsoleTest.DataBySplitFile.BackTest.ValueObject;
using CommonUtil.Helper.CSVLoad;

namespace ConsoleTest.DataBySplitFile.BackTest.Strategy.WeekLine.Data
{
    public class Buy7DayData
    {
        string connStr = @"D:\marketData\TWF_Data\Average";
        string fileName = @"Buy7Day.csv";


        string title =
            "Type," +
            "BackTestId," +
            "Id1," +
            "Id2," +
            "Point," +
            "Money," +
            "StopLosePointEmpty," +
            "StopLosePointMulit," +
            "Selled," +
            "Product," +
            "Date," +
            "BeforePoint," +
            "AvePoint"
            ;
        ProductInfoVO productVO;
        
        CsvConnection csvConn = null;
        public Buy7DayData(ProductInfoVO productVO)
        {
            csvConn = new CsvConnection(connStr);
            csvConn.SetRunFileName(fileName);
            this.productVO = productVO;
        }

        public void DeleteAll()
        {
            csvConn.DeleteAll();
        }

        public List<BuyVO> FindAll(Func<BuyVO, bool> filter)
        {
            List<BuyVO> dataList = new List<BuyVO>();
            csvConn.Query((idx, convert) =>
            {
                BuyVO buyVO = this.ToBuyEntity(convert);
                if (filter != null && !filter(buyVO))
                {
                    return;
                }
                dataList.Add(buyVO);
            });

            return dataList;
        }
        /// <summary>
        /// 更新已賣掉
        /// </summary>
        /// <param name="vo"></param>
        /// <param name="type"></param>
        public void UpdateSelled(List<BuyVO> vo)
        {
            HashSet<Guid> set = new HashSet<Guid>(vo.Select(s => s.BackTestId));
            StringBuilder content = new StringBuilder();
            csvConn.Query((idx, convert) =>
            {
                BuyVO buyVO = this.ToBuyEntity(convert);
                if (set.Contains(buyVO.BackTestId))
                {
                    buyVO.Selled = "Y";
                }
                content.AppendLine(ToCsvContent(buyVO));
            });

            csvConn.Save(title, content.ToString());
        }
        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="vo"></param>
        /// <param name="type"></param>
        public void Insert(BuyVO vo)
        {
            csvConn.Insert(title, ToCsvContent(vo) + "\r\n");
        }

        /// <summary>
        /// 轉成entity
        /// </summary>
        /// <param name="convert"></param>
        /// <returns></returns>
        private BuyVO ToBuyEntity(CSVLoadConvert convert)
        {
            return new BuyVO()
            {
                Type = convert.GetByIndex<int>(0),
                BackTestId = convert.GetByIndex<Guid>(1),
                ID1 = convert.GetByIndex<string>(2),
                ID2 = convert.GetByIndex<string>(3),
                Point = convert.GetByIndex<int>(4),
                StopLosePointEmpty = convert.GetByIndex<int>(6),
                StopLosePointMulit = convert.GetByIndex<int>(7),
                Selled = convert.GetByIndex<string>(8),
                ProductInfoVO = this.productVO,
                Date = convert.GetByIndex<DateTime>(10),
                BeforePoint = convert.GetByIndex<int>(11),
                AvePoint = convert.GetByIndex<int>(12),
            };
        }

        /// <summary>
        /// 轉成csv文字
        /// </summary>
        /// <param name="vo"></param>
        /// <returns></returns>
        private string ToCsvContent(BuyVO vo)
        {


            return
                vo.Type + ","
                + vo.BackTestId.ToString() + ","
                + vo.ID1 + ","
                + vo.ID2 + ","
                + vo.Point + ","
                + vo.Money + ","
                + vo.StopLosePointEmpty + ","
                + vo.StopLosePointMulit + ","
                + vo.Selled + ","
                + vo.ProductInfoVO.Name + ","
                + vo.Date.ToString("yyyy/MM/dd HH:mm:ss") + ","
                + vo.BeforePoint + ","
                + vo.AvePoint
                ;
        }



    }
}
