﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CommonUtil.Helper.CSVLoad.Plus;
using ConsoleTest.DataBySplitFile.BackTest.Entity;
using CommonUtil.Helper.CSVLoad;
using System.Globalization;
using ConsoleTest.DataBySplitFile.BackTest.MainData;

namespace ConsoleTest.DataBySplitFile.BackTest.Strategy.WeekLine.Data
{
    public class AvgDayData : AvgData
    {
        string connStr = @"D:\marketData\TWF_Data\Average\";
        string fileName = @"7Day.csv";

        int day;
        public AvgDayData(int day)
        {
            base.Init(connStr, fileName);
            this.day = day;
        }


        /// <summary>
        /// 查詢全部
        /// </summary>
        /// <param name="filter"></param>
        /// <returns></returns>
        public List<DailyAverageEntity> FindAll(Func<DailyAverageEntity, bool> filter)
        {
            List<DailyAverageEntity> dataList = new List<DailyAverageEntity>();
            csvConn.Query((idx, convert) =>
            {
                DailyAverageEntity entity = this.ToDailyAverageEntity(convert);
                if (filter != null && filter(entity))
                {
                    return;
                }
                dataList.Add(entity);
            });

            return dataList;
        }

        /// <summary>
        /// 查詢均值
        /// </summary>
        /// <param name="date"></param>
        /// <param name="day"></param>
        /// <returns></returns>
        public override DailyAverageEntity GetAverage(int nowClose, DateTime nowDateTime)
        {
            List<DailyAverageEntity> list = new List<DailyAverageEntity>();
            csvConn.Query((idx, convert) =>
            {
                list.Add(ToDailyAverageEntity(convert));
            });


            List<DailyAverageEntity> aveList = new List<DailyAverageEntity>();
            bool isAddList = false;
            for (int row = list.Count - 1; row >= 0; row--)
            {
                DailyAverageEntity dateEntity = list[row];
                if (!isAddList)
                {
                    isAddList = dateEntity.DateTime < nowDateTime;
                    if (!isAddList)
                    {
                        continue;
                    }
                }

                aveList.Add(dateEntity);
                if (day - 1 == aveList.Count)
                {
                    break;
                }
            }

            DailyAverageEntity nowEntity = new DailyAverageEntity()
            {
                DateTime = nowDateTime,
                Close = nowClose,
                Unit = day
            };
            aveList.Add(nowEntity);
            nowEntity.Average = (int)aveList.Average(a => a.Close);

            return nowEntity;
        }



        /// <summary>
        /// 取得前一筆的資料
        /// </summary>
        /// <param name="nowDateTime"></param>
        /// <returns></returns>
        public override DailyAverageEntity GetBeforeData(DateTime nowDateTime)
        {
            DateTime minDateTime = nowDateTime.AddDays(-5);
            DateTime maxDateTime = nowDateTime.AddDays(-1);
            DailyAverageEntity obj = null;
            csvConn.Query((idx, convert) =>
            {
                DateTime closDate = convert.GetByIndex<DateTime>(0);
                if (closDate > minDateTime && closDate < maxDateTime)
                {
                    obj = ToDailyAverageEntity(convert);
                }
            });

            return obj;
        }



        protected DailyAverageEntity ToDailyAverageEntity(CSVLoadConvert convert)
        {
            return new DailyAverageEntity()
            {
                DateTime = convert.GetByIndex<DateTime>(0),
                Close = convert.GetByIndex<int>(1),
                Average = convert.GetByIndex<int>(2),
                Unit = convert.GetByIndex<int>(3),
            };
        }

    }
}
