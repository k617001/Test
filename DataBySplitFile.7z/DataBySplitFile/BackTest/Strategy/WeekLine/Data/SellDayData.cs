﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ConsoleTest.DataBySplitFile.BackTest.ValueObject;
using CommonUtil.Helper.CSVLoad.Plus;
using ConsoleTest.DataBySplitFile.BackTest.MainData;

namespace ConsoleTest.DataBySplitFile.BackTest.Strategy.WeekLine.Data
{
    public class SellDayData : SellData
    {
        string connStr = @"D:\marketData\TWF_Data\Average";
        string fileName = @"Sell7Day.csv";

        public SellDayData(ProductInfoVO productVO)
            : base(productVO)
        {
            base.Init(connStr, fileName);
        }

    }
}
