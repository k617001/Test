﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CommonUtil.Helper.CSVLoad.Plus;
using ConsoleTest.DataBySplitFile.BackTest.Entity;
using CommonUtil.Helper.CSVLoad;
using System.Globalization;

namespace ConsoleTest.DataBySplitFile.BackTest.Strategy.WeekLine.Data
{
    public class WeekLineDayData
    {
        string connStr = @"D:\marketData\TWF_Data\Day";
        CsvConnection csvConn = null;
        public WeekLineDayData()
        {
            csvConn = new CsvConnection(connStr);
        }

        /// <summary>
        /// 依天查詢所有資料的均值，只記錄某段時間的值(一天一筆)
        /// </summary>
        /// <param name="date"></param>
        /// <param name="day"></param>
        /// <returns></returns>
        public List<DailyAverageEntity> FindListDailyAverage(int day, string timeFilterHHMM)
        {
            string[] fileNames = csvConn.GetFileNames();

            //把所有的close拉到list裡
            List<DailyAverageEntity> list = new List<DailyAverageEntity>();
            for (int i = 0; i < fileNames.Length; i++ )
            {
                csvConn.SetRunFileName(fileNames[i]);
                csvConn.Query((idx, convert) =>
                {
                    
                    string time = convert.GetByIndex<string>(1);

                    if (!timeFilterHHMM.Equals(time))
                    {
                        return;
                    }
                    list.Add(ToDailyAverageEntity(convert));
                });


                
            }

            List<DailyAverageEntity> dayList = new List<DailyAverageEntity>();
            foreach(DailyAverageEntity aveEntity in list) {
                aveEntity.Unit = day;
                dayList.Add(aveEntity);
                if (dayList.Count < day+1)
                {
                    continue;
                }

                dayList.RemoveAt(0);
                aveEntity.Unit = dayList.Count;
                aveEntity.Average = (int)dayList.Average(a => a.Close);
            }

            return list;
        }

        private DailyAverageEntity ToDailyAverageEntity(CSVLoadConvert convert)
        {
            return new DailyAverageEntity()
            {
                DateTime = GetDateTime(convert),
                Close = convert.GetByIndex<int>(5),
            };
        }

        private DailyEntity ToDailyEntity(CSVLoadConvert convert)
        {
            return new DailyEntity()
            {
                DateTime = GetDateTime(convert),
                Open = convert.GetByIndex<int>(2),
                High = convert.GetByIndex<int>(3),
                Low = convert.GetByIndex<int>(4),
                Close = convert.GetByIndex<int>(5),
                Volume = convert.GetByIndex<int>(6),
            };
        }

        private DateTime GetDateTime(CSVLoadConvert convert)
        {
            string dateStr = convert.GetByIndex<string>(0);
            string time = convert.GetByIndex<string>(1);

            string[] timeAry = time.Split(':');

            if (timeAry[0].Length == 1)
            {
                timeAry[0] = "0" + timeAry[0];
            }
            time = timeAry[0] + ":" + timeAry[1];
            return DateTime.ParseExact(dateStr + " " + time, "yyyy/MM/dd HH:mm", CultureInfo.InvariantCulture);

        }
    }
}
