﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CommonUtil.Helper.CSVLoad.Plus;
using ConsoleTest.DataBySplitFile.BackTest.Strategy.WeekLine.Data;
using ConsoleTest.DataBySplitFile.BackTest.Entity;
using CommonUtil;

namespace ConsoleTest.DataBySplitFile.BackTest.Strategy.WeekLine.Batch
{
    public class ToAvgCSVBatchAction
    {
        string targetPath = @"D:\marketData\TWF_Data\Average\7Day.csv";

        int day = WeekLineSetting.DAY;
        string timeFilter = "13:00";
        WeekLineDayData data = new WeekLineDayData();

        public void Action()
        {
            List<DailyAverageEntity> aveList = data.FindListDailyAverage(day, timeFilter);

            StringBuilder content = new StringBuilder();

            content.AppendLine("Date,Close,Average,Day");
            foreach (DailyAverageEntity entity in aveList)
            {
                content.AppendLine(
                    entity.DateTime.ToString("yyyy/MM/dd") + "," + 
                    entity.Close + "," + 
                    entity.Average + "," + 
                    entity.Unit
                    );
            }

            CommonTool.StringToFile(targetPath, content.ToString());
        }
    }
}
