﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ConsoleTest.DataBySplitFile.BackTest.ValueObject;
using ConsoleTest.DataBySplitFile.BackTest.WeekLine.WeekLineAction;
using ConsoleTest.DataBySplitFile.BackTest.Strategy.WeekLine.Data;
using ConsoleTest.DataBySplitFile.BackTest.Entity;
using System.IO;
using ConsoleTest.DataBySplitFile.BackTest.Strategy.WeekLine.Batch;
using ConsoleTest.DataBySplitFile.BackTest.MinuteLine.MinuteLineAction;
using ConsoleTest.DataBySplitFile.BackTest.Strategy.MinuteLine.Data;
using ConsoleTest.DataBySplitFile.BackTest.MainData;
using ConsoleTest.DataBySplitFile.BackTest.Strategy.MinuteLine.Batch;
using CommonUtil.Helper.CSVLoad.Plus;

namespace ConsoleTest.DataBySplitFile.BackTest.Strategy.WeekLine
{
    public class MinuteLineActionTest
    {


        ProductInfoVO productVO = new ProductInfoVO()
        {
            NameId = "TX",
            NickName = "TX",
            Name = "TX",
            Fee = 100,
            PointMoney = 50,
            StopLosePoint = 20, //小於n點賣出
        };

        public void Action()
        {
            string connStr = @"D:\marketData\TWF_Data\Day";
            CsvConnection csvConn = new CsvConnection(connStr);
            string [] files = csvConn.GetFileNames().Where(w => w.Contains("2015_03")).ToArray();
            //設定
            foreach (string fileName in files)
            {
                int[] dateStr = fileName.Replace(".csv","").Split('_').Select(s => Convert.ToInt32(s)).ToArray();

                if (dateStr[0] != 2015)
                {
                    continue;
                }
                if (dateStr[1] != 3)
                {
                    continue;
                }
                if (dateStr[2] != 24)
                {
                    continue;
                }

                DateTime date = new DateTime(dateStr[0], dateStr[1], dateStr[2]);
                this.Minute30(date);
            }
        }

        public void Minute30(DateTime date)
        {
            //設定
            int minute = 30;

            //轉檔
            new MinuteToAvgCSV(productVO, date, minute).Action();

            //策略設定(週線)
            MinuteLineAction action = new MinuteLineAction(
                productVO,
                new AvgMintueData(date, minute),
                new BuyMinuteData(productVO),
                new SellMinuteData(productVO)
                );
            //action.Clear();
            
            DayData dayData = new DayData();
            List<DailyEntity> dalyList = dayData.FindDayList(date.ToString("yyyy_MM_dd"));

            foreach(DailyEntity entity in dalyList) 
            {
                NowDataVO nowData = new NowDataVO()
                {
                    Date = entity.DateTime,
                    Close = entity.Close,
                    Volume = entity.Volume
                };

                nowData.PrintData();
                action.StrategyAction(nowData);
            }

        }
    }
}
