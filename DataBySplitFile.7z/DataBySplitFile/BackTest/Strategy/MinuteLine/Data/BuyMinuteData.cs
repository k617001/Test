﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CommonUtil.Helper.CSVLoad.Plus;
using ConsoleTest.DataBySplitFile.BackTest.ValueObject;
using CommonUtil.Helper.CSVLoad;
using ConsoleTest.DataBySplitFile.BackTest.MainData;
using ConsoleTest.DataBySplitFile.BackTest.Strategy.MinuteLine;

namespace ConsoleTest.DataBySplitFile.BackTest.Strategy.WeekLine.Data
{
    public class BuyMinuteData : BuyData
    {
        string connStr = MinuteLineConfig.FILE_PATH;
        string fileName = @"BuyMinute.csv";

        public BuyMinuteData(ProductInfoVO productVO)
            : base(productVO)
        {
            base.Init(connStr, productVO, fileName);
        }

    }
}
