﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ConsoleTest.DataBySplitFile.BackTest.ValueObject;
using CommonUtil.Helper.CSVLoad.Plus;
using ConsoleTest.DataBySplitFile.BackTest.MainData;
using ConsoleTest.DataBySplitFile.BackTest.Strategy.MinuteLine;

namespace ConsoleTest.DataBySplitFile.BackTest.Strategy.WeekLine.Data
{
    public class SellMinuteData : SellData
    {
        string connStr = MinuteLineConfig.FILE_PATH;
        string fileName = @"SellMinute.csv";

        public SellMinuteData(ProductInfoVO productVO)
            : base(productVO)
        {
            base.Init(connStr, productVO, fileName);
        }

    }
}
