﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ConsoleTest.DataBySplitFile.BackTest.ValueObject;

namespace ConsoleTest.DataBySplitFile.BackTest.Strategy.Base
{
	public abstract class BaseStrategy
    {
        /// <summary>
        /// 產品設定
        /// </summary>
        public ProductInfoVO ProductInfo { set; get; }


        public void Action(NowDataVO data)
        {
            //StrategyAction(data);
        }

        //public abstract void StrategyAction(NowDataVO data);
	}
}
