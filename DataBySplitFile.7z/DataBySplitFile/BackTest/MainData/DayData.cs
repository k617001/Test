﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CommonUtil.Helper.CSVLoad.Plus;
using ConsoleTest.DataBySplitFile.BackTest.Entity;
using CommonUtil.Helper.CSVLoad;
using System.Globalization;

namespace ConsoleTest.DataBySplitFile.BackTest.MainData
{
    /// <summary>
    /// 取得日的資料
    /// </summary>
    public class DayData
    {
        string connStr = @"D:\marketData\TWF_Data\Day";
        CsvConnection csvConn = null;
        public DayData()
        {
            csvConn = new CsvConnection(connStr);
        }


        /// <summary>
        /// 查詢日資料
        /// </summary>
        /// <param name="filterStr"></param>
        /// <returns></returns>
        public List<DailyEntity> FindDayList(string filterStr)
        {
            string[] fileNames = csvConn.GetFileNames();

            string outputFileName = null;
            foreach (string fileName in fileNames)
            {
                if (fileName.Contains(filterStr))
                {
                    outputFileName = fileName;
                    break;
                }

            }

            if (outputFileName == null)
            {
                return null;
            }

            List<DailyEntity> list = new List<DailyEntity>();
            csvConn.SetRunFileName(outputFileName).Query((idx, convert) =>
            {
                list.Add(this.ToDailyEntity(convert));
            });

            return list;
        }

        public void FindDayAction(string year, Action<DailyEntity> backTest)
        {
            string[] fileNames = csvConn.GetFileNames();

            foreach(string fileName in fileNames) 
            {
                Console.WriteLine(fileName);
                if (!fileName.Contains(year))
                {
                    continue;
                }

                csvConn.SetRunFileName(fileName).Query((idx, convert) => {
                    backTest(this.ToDailyEntity(convert));
                });
            }
        }

        private DailyEntity ToDailyEntity(CSVLoadConvert convert)
        {
            return new DailyEntity()
            {
                DateTime = GetDateTime(convert),
                Open = convert.GetByIndex<int>(2),
                High = convert.GetByIndex<int>(3),
                Low = convert.GetByIndex<int>(4),
                Close = convert.GetByIndex<int>(5),
                Volume = convert.GetByIndex<int>(6),
            };
        }

        private DateTime GetDateTime(CSVLoadConvert convert)
        {
            string dateStr = convert.GetByIndex<string>(0);
            string time = convert.GetByIndex<string>(1);

            string[] timeAry = time.Split(':');

            if (timeAry[0].Length == 1)
            {
                timeAry[0] = "0" + timeAry[0];
            }
            time = timeAry[0] + ":" + timeAry[1];
            return DateTime.ParseExact(dateStr + " " + time, "yyyy/MM/dd HH:mm", CultureInfo.InvariantCulture);

        }
    }
}
