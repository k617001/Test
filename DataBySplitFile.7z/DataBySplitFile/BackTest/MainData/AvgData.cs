﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CommonUtil.Helper.CSVLoad.Plus;
using ConsoleTest.DataBySplitFile.BackTest.Entity;
using CommonUtil.Helper.CSVLoad;
using ConsoleTest.DataBySplitFile.BackTest.Base;

namespace ConsoleTest.DataBySplitFile.BackTest.MainData
{
    public abstract class AvgData : BaseData
    {
        /// <summary>
        /// 查詢均值
        /// </summary>
        /// <param name="nowClose"></param>
        /// <param name="unit">均線單位值</param>
        /// <param name="nowDateTime"></param>
        /// <returns></returns>
        public abstract DailyAverageEntity GetAverage(int nowClose, DateTime nowDateTime);
        /// <summary>
        /// 取得前一筆的資料
        /// </summary>
        /// <param name="nowClose"></param>
        /// <param name="unit">均線單位值</param>
        /// <param name="nowDateTime"></param>
        /// <returns></returns>
        public abstract DailyAverageEntity GetBeforeData(DateTime nowDateTime);


    }
}
