﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataBySplitFile.Common.CSVLoad;
using Newtonsoft.Json;

namespace ConsoleTest.DataBySplitFile
{
    public class DataToJson
    {
        string filePath = @"D:\marketData\PROG_TWF_1min_Part2_19980722_20150325.txt";
        string targetDir = @"D:\marketData\TWF_Data\";

        public void Action()
        {

            AnalysisMarketVO vo = new AnalysisMarketVO();

            CSVLoadHelper.LoadCsv(filePath, (row, convert) =>
            {
                string date = convert.Get<string>("date");
                string time = convert.Get<string>("time");
                string dt = date + " " + (time.Length > 5 ? time : time + ":00");
                DateTime dateTime = Convert.ToDateTime(dt);

                vo.Date.Add(dateTime);
                vo.Open.Add(convert.Get<int>("Open"));
                vo.High.Add(convert.Get<int>("High"));
                vo.Low.Add(convert.Get<int>("Low"));
                vo.Close.Add(convert.Get<int>("Close"));
                vo.Volume.Add(convert.Get<int>("Volume"));
            });


            VolumeJson(vo, "");

            object[] valueObj = new object[] 
            {
                new {
                    name = "Open",
                    data = vo.Open,
                },
                new {
                    name = "High",
                    data = vo.High,
                },
                new {
                    name = "Low",
                    data = vo.Low,
                },
                new {
                    name = "Volume",
                    data = vo.Volume,
                },

            };
        }

        private void VolumeJson(AnalysisMarketVO vo, string filePath)
        {

            object[] volumeObj = new object[] 
            {
                new {
                    name = "Volume",
                    data = vo.Volume,
                },
            };

            

            string output = JsonConvert.SerializeObject(volumeObj);
        }
    }

}
