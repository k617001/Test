﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Unity;
using Unity.Interception.ContainerIntegration;
using Unity.Interception.Interceptors.InstanceInterceptors.InterfaceInterception;
using Unity.Interception.InterceptionBehaviors;
using Unity.Interception.Interceptors.TypeInterceptors.VirtualMethodInterception;
using Unity.Interception.Interceptors.InstanceInterceptors.TransparentProxyInterception;

namespace ConsoleTest.UnityTest
{
    public class StartUnity
    {
        public void Action()
        {

            IUnityContainer unityContainer = new UnityContainer();
            UnityContainerAdaper container = new UnityContainerAdaper(unityContainer);
            container
                .RegisterType<IBO, XxxxxBO>()
                .RegisterType<IBO2, Xxxxx2BO>()
                ;


            IBO bo = unityContainer.Resolve<IBO>();
            bo.Action();
        }
    }

    /// <summary>
    /// 轉接器-AOP
    /// 用此物件來延伸包裝物件，
    /// 使用時就預設這些物件被延伸的物件關注
    /// </summary>
    public class UnityContainerAdaper
    {
        IUnityContainer container;

        Interceptor<InterfaceInterceptor> interceptor = new Interceptor<InterfaceInterceptor>();
        InterceptionBehavior<LoggingInterceptionBehavior> behavior = new InterceptionBehavior<LoggingInterceptionBehavior>();

        public UnityContainerAdaper(IUnityContainer container)
        {
            this.container = container;
            container.AddNewExtension<Interception>();
        }

        public UnityContainerAdaper RegisterType<TFrom, TTo>() where TTo : TFrom
        {
            this.container.RegisterType<TFrom, TTo>(interceptor, behavior);
            return this;
        }
    }
}
