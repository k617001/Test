﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Unity.Interception.InterceptionBehaviors;
using Unity.Interception.PolicyInjection.Pipeline;
using log4net;

namespace ConsoleTest.UnityTest
{
    public class LoggingInterceptionBehavior : IInterceptionBehavior
    {
        public IMethodReturn Invoke(IMethodInvocation input, GetNextInterceptionBehaviorDelegate getNext)
        {

            ILog log = LogManager.GetLogger(Type.GetType(input.Target.ToString()));

            log.Debug(GetLogMsg(input, "Invoking method"));

            var result = getNext()(input, getNext);
            if (result.Exception != null)
            {

                return result;
            }

            log.Debug(GetLogMsg(input, "Return method"));

            return result;
        }

        private string GetLogMsg(IMethodInvocation input, string msg)
        {
            return String.Format(msg + " {0}", input.MethodBase);
        }

        public IEnumerable<Type> GetRequiredInterfaces()
        {
            return Type.EmptyTypes;
        }

        public bool WillExecute
        {
            get { return true; }
        }

        private void WriteLog(string message)
        {
            Console.WriteLine(message);
        }
    }
}
