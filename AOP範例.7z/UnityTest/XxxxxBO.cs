﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using System.Reflection;

namespace ConsoleTest.UnityTest
{
    public interface IBO
    {
        void Action();
    }
    public class XxxxxBO : IBO
    {
        IBO2 bo2;
        public XxxxxBO(IBO2 bo2)
        {
            this.bo2 = bo2;
        }

        public void Action()
        {
            Console.WriteLine("--->Run XxxxxBO Action()");
            this.bo2.Action();
        }
    }
}
