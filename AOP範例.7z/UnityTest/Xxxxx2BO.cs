﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleTest.UnityTest
{
    public interface IBO2
    {
        void Action();
    }
    public class Xxxxx2BO : IBO2
    {
        public void Action()
        {
            Console.WriteLine("--->Run Xxxxx2BO Action()");
        }
    }
}
