﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BallotAiying2;
using System.Drawing;
using CommonUtil;
using System.Drawing.Imaging;
using CommonUtil.Helper.BallotAiying2;
using System.Diagnostics;

namespace ConsoleTest.BallotAiyingTest
{
    public class BaTest3
    {
        int gValue = 0;


        public void Action()
        {
            Bitmap bmpobj = new Bitmap(@"D:\333.png");

            Stopwatch sw = new Stopwatch();
            sw.Reset();
            sw = Stopwatch.StartNew();

            gValue = 128;
            //sobel
            Bitmap sobel = this.Gv2Sobel(bmpobj);

            sobel.Save(@"D:\128.png", ImageFormat.Png);

            sw.Stop();
            double s = (double)sw.ElapsedMilliseconds / 1000;
            Console.WriteLine("花費 {0} 秒", s);
        }
        
        /// <summary>
        /// sobel
        /// </summary>
        /// <param name="bmpobj"></param>
        /// <param name="runFun"></param>
        /// <returns></returns>
        private Bitmap Gv2Sobel(Bitmap bmpobj)
        {

            GrayValue2(bmpobj);
            //int[, ,] rgbData3 = Sobel(rgbData2);

            return bmpobj;
        }

        
        /// <summary>
        /// 灰階二值化合併
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <param name="rgbData"></param>
        private void GrayValue2(Bitmap bmpobj)
        {
            for (int i = 0; i < bmpobj.Height; i++)
            {
                for (int j = 0; j < bmpobj.Width; j++)
                {
                    int tmpValue = GetGrayNumColor(bmpobj.GetPixel(j, i));
                    bmpobj.SetPixel(j, i, Color.FromArgb(tmpValue, tmpValue, tmpValue));
                }
            }
        }
        /// <summary>
        /// 根据RGB，计算灰度值
        /// </summary>
        /// <param name="posClr">Color值</param>
        /// <returns>灰度值，整型</returns>
        private int GetGrayNumColor(System.Drawing.Color posClr)
        {
            return (posClr.R * 19595 + posClr.G * 38469 + posClr.B * 7472) >> 16;
        }

        /// <summary>
        /// sobel
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <param name="rgbData"></param>
        private int[, ,] Sobel(int[, ,] rgbData)
        {
            int Width = rgbData.GetLength(0);
            int Height = rgbData.GetLength(1);

            int[, ,] rgbDataTmp = new int[Width, Height, 3];

            for (int y = 0; y < Height; y++)
            {
                for (int x = 0; x < Width; x++)
                {
                    if (x >= 1 && x < Width - 1 && y >= 1 && y < Height - 1)
                    {
                        int x0 = rgbData[x - 1, y, 0];
                        int x1 = rgbData[x, y, 0];
                        int x2 = rgbData[x + 1, y, 0];

                        int y0 = rgbData[x, y - 1, 0];
                        int y2 = rgbData[x, y + 1, 0];

                        if (x0 == 0 && x1 == 0 && x2 == 0
                            && y0 == 0  && y2 == 0)
                        {
                            rgbDataTmp[x, y, 0] = 255;
                            rgbDataTmp[x, y, 1] = 255;
                            rgbDataTmp[x, y, 2] = 255;
                        }
                        else
                        {
                            rgbDataTmp[x, y, 0] = rgbData[x, y, 0];
                            rgbDataTmp[x, y, 1] = rgbData[x, y, 1];
                            rgbDataTmp[x, y, 2] = rgbData[x, y, 2];
                        }
                    }
                }
            }

            return rgbDataTmp;
        }

    }
}
