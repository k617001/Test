﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CommonUtil.ObjectContainer;
using ConsoleTest.BusinessLogic.Interface;
using ConsoleTest.BusinessLogic.Implement;

namespace ConsoleTest.BusinessLogic.Register
{
    public class RegisterBL
    {
        public static void Register(Container container) 
        {
            int version = 1;
            if (version == 1)
            {
                RegVersion1(container);
            }
            else if (version == 2)
            {
                RegVersion2(container);
            }
        }

        public static void RegVersion1(Container container)
        {
            container
                .RegisterType<IEmployeeBL, EmployeeBL>()
                ;
        }

        public static void RegVersion2(Container container)
        {
            container
                .RegisterType<IEmployeeBL, Employee2BL>()
                ;
        }


    }
}
