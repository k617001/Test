﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using CommonUtil.Helper.DBHelper;
using System.Data;

namespace ConsoleTest.AdoNetBatch
{
    public class BatchTest
    {
        public void Action()
        {
            string connStr = "Database=BriViewDQA;Server=fhtwdbt01;uid=PLM.AP;pwd=plm@AP";
            BatchHelper helper = new BatchHelper(connStr);

            string delSQL = "delete dbo.zzTestTable_20170612";
            helper.ExecuteSQL(delSQL, null);

            DataTable data = GetData(200000);
            helper.BatchInsert("zzTestTable_20170612", data);

            helper.Commit();
        }

        private DataTable GetData(int size)
        {
            DataTable result = new DataTable();
            DataColumn sn = new DataColumn("sn", typeof(long));
            sn.AutoIncrement = true;
            result.Columns.Add(sn);
            result.Columns.Add(new DataColumn("Test", typeof(String)));

            string content = DateTime.Now.ToString("HH_mm_ss");

            for (int i = 0; i < size; i++)
            {
                DataRow workRow = result.NewRow();
                workRow["Test"] = content;
                result.Rows.Add(workRow);
            }

            return result;
        }
    }
}
