﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Newtonsoft.Json;

namespace ConsoleTest.DataBySplitFile.Common
{
    public class ComUtil
    {
        /// <summary>
        /// 寫入至目標js
        /// </summary>
        /// <param name="content"></param>
        /// <param name="filePath"></param>
        /// <param name="isDelete">設false時會用累計的方式增加檔案</param>
        public static void CreateDataJsFile(string name, object dataObj, string filePath)
        {
            string resultJson = JsonConvert.SerializeObject(dataObj);

            string jsContent = @"var " + name + " = " + resultJson + ";";

            Str2File(jsContent, filePath + name + ".js");
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="content"></param>
        /// <param name="filePath"></param>
        /// <param name="isDelete">設false時會用累計的方式增加檔案</param>
        public static void Str2File(string content, string filePath, bool isDelete = true)
        {
            string dir = Path.GetDirectoryName(filePath);//取得目錄
            if(!Directory.Exists(dir)) //無路徑時產生錄目
            {
                Directory.CreateDirectory(dir);
            }

            if (File.Exists(filePath) && isDelete) 
            {
                File.Delete(filePath);
            }

            using (StreamWriter outputFile = new StreamWriter(filePath, true))
            {
                outputFile.WriteLine(content);
            }
        }
    }
}
