﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataBySplitFile.Common.CSVLoad;
using Newtonsoft.Json;
using System.IO;
using ConsoleTest.DataBySplitFile.Common;
using System.Globalization;

namespace ConsoleTest.DataBySplitFile
{
    /// <summary>
    /// 把值規０，所有值減掉開盤價
    /// 把日漲跌的csv資料，變成js檔，畫成highchart
    /// </summary>
    public class DayCloseReportData
    {
        string filePath = RunAction.TARGET_DIR + @"Daily\MTX\";
        string targetPath = RunAction.HTML_REPORT_DIR + @"Data\";
        string jsName = "DayClose";

        StringBuilder content = new StringBuilder();

        DayCloseForChart groupChart = new DayCloseForChart();

        public void Action()
        {
            string[] paths = Directory.GetFiles(filePath);

            foreach (string path in paths) 
            {
                this.LoadDayFile(path);
            }
            //寫入至資料js檔案
            ComUtil.CreateDataJsFile(jsName, groupChart.Day, targetPath);

        }

        private void LoadDayFile(string path)
        {
            Console.WriteLine(path);
            CSVLoadHelper.LoadCsv(path, (row, convert) =>
            {
                SetGroup(convert, "yyyy-MM-dd", groupChart.Day);
            });

        }



        /// <summary>
        /// 設定群組
        /// </summary>
        /// <param name="convert"></param>
        /// <param name="dateFormat"></param>
        /// <param name="group"></param>
        Dictionary<string, int> dayClose = new Dictionary<string, int>();
        private void SetGroup(
            CSVLoadConvert convert,
            string dateFormat,
            Dictionary<string, DayObjForChart> groupMap
            )
        {
            string date = convert.Get<string>("date");
            string time = convert.Get<string>("time");
            string dt = date + " " + (time.Length > 5 ? time : time + ":00");
            DateTime dateTime = Convert.ToDateTime(dt);
            string groupName = dateTime.ToString(dateFormat);
            int close = convert.Get<int>("Close");

            DayObjForChart chartData = null;
            if (!groupMap.ContainsKey(groupName))
            {
                groupMap.Add(groupName, new DayObjForChart());
            }
            chartData = groupMap[groupName];

            chartData.Date.Add(dateTime.ToString("HH:mm"));
            chartData.Close.Add(close);
            chartData.Volume.Add(convert.Get<int>("Volume"));

            this.AvgList(dateTime, 30, chartData.Ave30m, chartData);
            this.AvgList(dateTime, 60, chartData.Ave60m, chartData);
            /*
            this.AvgList(dateTime, 5, chartData.Ave5m, chartData);
            this.AvgList(dateTime, 10, chartData.Ave10m, chartData);
            this.AvgList(dateTime, 20, chartData.Ave20m, chartData);
             * */
        }

        /// <summary>
        /// 平均線記錄
        /// </summary>
        /// <param name="dateTime"></param>
        /// <param name="minute"></param>
        /// <param name="avgList"></param>
        /// <param name="chartData"></param>
        private void AvgList(DateTime dateTime, int minute, List<int> avgList, DayObjForChart chartData)
        {
            DateTime sTime = dateTime.AddMinutes(minute * -1);

            List<int> saveAvgList = new List<int>();
            for (DateTime start = sTime; start <= dateTime; start = start.AddMinutes(1))
            {
                string hourMin = start.ToString("HH:mm");
                int idx = GetDateIdx(hourMin, chartData.Date);
                if (int.MinValue == idx)
                {
                    continue;
                }

                saveAvgList.Add(chartData.Close[idx]);
            }

            avgList.Add((int)Math.Round(saveAvgList.Average(), 0));
        }

        /// <summary>
        /// 取得key的index
        /// </summary>
        /// <param name="dayKey"></param>
        /// <param name="dates"></param>
        /// <returns></returns>
        private int GetDateIdx(string dayKey, List<string> dates)
        {
            for (int i = 0; i < dates.Count; i++)
            {
                if (dates[i].Equals(dayKey))
                {
                    return i;
                }
            }
            return int.MinValue;
        }


        public class DayCloseForChart
        {
            public DayCloseForChart()
            {
                Day = new Dictionary<string, DayObjForChart>();
            }

            public Dictionary<string, DayObjForChart> Day { set; get; }
        }

        public class DayObjForChart
        {
            public DayObjForChart()
            {
                Date = new List<string>();
                Close = new List<int>();
                Volume = new List<int>();

                Ave30m = new List<int>();
                Ave60m = new List<int>();
                Ave7d = new List<int>();
                /*
                Ave5m = new List<int>();
                Ave10m = new List<int>();
                Ave20m = new List<int>();
                Ave30m = new List<int>();
                 * */
            }

            public List<string> Date { set; get; }

            public List<int> Close { set; get; }

            public List<int> Volume { set; get; }

            public List<int> Ave7d { set; get; }
            public List<int> Ave30m { set; get; }
            public List<int> Ave60m { set; get; }

            /*
            public List<int> Ave5m { set; get; }
            public List<int> Ave10m { set; get; }
            public List<int> Ave20m { set; get; }
            public List<int> Ave30m { set; get; }
             * */
        }
    }
}
