﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataBySplitFile.Common.CSVLoad;
using Newtonsoft.Json;
using System.IO;
using ConsoleTest.DataBySplitFile.Common;
using System.Globalization;

namespace ConsoleTest.DataBySplitFile
{
    /// <summary>
    /// 把值規０，所有值減掉開盤價
    /// 把日漲跌的csv資料，變成js檔，畫成highchart
    /// </summary>
    public class DayCloseReportData2
    {
        string filePath = RunAction.TARGET_DIR + @"Day\";
        string targetPath = RunAction.HTML_REPORT_DIR + @"Data\";
        string jsName = "DayClose2";

        StringBuilder content = new StringBuilder();

        DayCloseForChart groupChart = new DayCloseForChart();

        public void Action()
        {
            string[] paths = Directory.GetFiles(filePath);

            foreach (string path in paths) 
            {
                this.LoadDayFile(path);
            }
            //寫入至資料js檔案
            ComUtil.CreateDataJsFile(jsName, groupChart.Month, targetPath);

        }

        private void LoadDayFile(string path)
        {
            Console.WriteLine(path);
            CSVLoadHelper.LoadCsv(path, (row, convert) =>
            {
                SetGroup(convert, "yyyy-MM-dd", groupChart.Month);
            });
        }

        /// <summary>
        /// 設定群組
        /// </summary>
        /// <param name="convert"></param>
        /// <param name="dateFormat"></param>
        /// <param name="group"></param>
        Dictionary<string, int> dayClose = new Dictionary<string, int>();
        string beforeDay = "2010/01/01";
        private void SetGroup(
            CSVLoadConvert convert,
            string dateFormat,
            Dictionary<string, DayObjForChart> groupMap
            )
        {
            string date = convert.Get<string>("date");
            int close = convert.Get<int>("Close");
            int volume = convert.Get<int>("Volume");


            DateTime date2 = DateTime.ParseExact(date, "yyyy/MM/dd", CultureInfo.InvariantCulture);
            string monthDate = date2.ToString("yyyy-MM");

            if (date2 < new DateTime(2005,1,1))
            {
                return;
            }

            if (beforeDay == date)
            {
                return;
            }

            beforeDay = date;

            if (!groupChart.Month.ContainsKey(monthDate))
            {
                groupChart.Month.Add(monthDate, new DayObjForChart());
            }
            DayObjForChart monthObj = groupChart.Month[monthDate];
            monthObj.Date.Add(date);
            monthObj.Close.Add(close);
            monthObj.Volume.Add(volume);

            if (!dayClose.ContainsKey(date))
            {
                dayClose.Add(date, close);
            }
            dayClose[date] = close;

            int day = 7;
            DateTime eDate = DateTime.ParseExact(date, "yyyy/MM/dd", CultureInfo.InvariantCulture);
            DateTime sDate = eDate.AddDays(day * -1);

            int closeAve = 0;
            int vaeDay = 0;
            for (; sDate < eDate; sDate = sDate.AddDays(1))
            {
                string dKey = sDate.ToString("yyyy/MM/dd");
                if(!dayClose.ContainsKey(dKey)) {
                    continue;
                }
                closeAve += dayClose[dKey];
                vaeDay++;
            }
            int av7d = vaeDay == 0 ? 0 :closeAve / vaeDay;
            monthObj.Ave7d.Add(av7d);
            /*
            this.AvgList(dateTime, 5, chartData.Ave5m, chartData);
            this.AvgList(dateTime, 10, chartData.Ave10m, chartData);
            this.AvgList(dateTime, 20, chartData.Ave20m, chartData);
            this.AvgList(dateTime, 30, chartData.Ave30m, chartData);
            this.AvgList(dateTime, 60, chartData.Ave60m, chartData);
             * */
        }


        public class DayCloseForChart
        {
            public DayCloseForChart()
            {
                Month = new Dictionary<string, DayObjForChart>();
            }

            public Dictionary<string, DayObjForChart> Month { set; get; }
        }

        public class DayObjForChart
        {
            public DayObjForChart()
            {
                Date = new List<string>();
                Close = new List<int>();
                Volume = new List<int>();

                Ave7d = new List<int>();
            }

            public List<string> Date { set; get; }

            public List<int> Close { set; get; }

            public List<int> Volume { set; get; }

            public List<int> Ave7d { set; get; }

        }
    }
}
