﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using CommonUtil.Helper.CSVLoad;
using System.Globalization;
using CommonUtil;

namespace ConsoleTest.DataBySplitFile.TickConvert
{
    /// <summary>
    /// Tick資料轉換
    /// </summary>
    public class TickToData
    {
        string filePath = RunAction.TARGET_DIR + @"Daily\";
        string targetPath = RunAction.TARGET_DIR + @"Daily\";

        string[] OUTPUT_NAME = new string[] { "TX","MTX" };

        public void Action()
        {
            /*
            string dateStr = DateTime.Now.AddDays(-1).ToString("yyyy_MM_dd");
            string[] paths = Directory.GetFiles(filePath)
                                    .Where(w => w.Contains("Daily_" + dateStr + ".csv"))
                                    .ToArray()
                                    ;
            */
            //所有檔案
            string[] paths = Directory.GetFiles(filePath).OrderBy(o => o).ToArray();

            foreach (string path in paths)
            {
                Console.WriteLine(path);
                CSVLoadHelper.LoadCsv(path, (row, convert) =>
                {
                    SetGroup(convert);
                });
            }

            SetToCSV();
        }

        private void SetToCSV()
        {
            foreach (string name in OUTPUT_NAME)
            {
                if (!groupResult.ContainsKey(name))
                {
                    throw new Exception("沒有這個商品阿，你是在大聲什麼!! => " + name);
                }
                List<TickResultDataVO> results = groupResult[name]
                                                    .OrderBy(o => o.DateTime)
                                                    .ToList();

                Dictionary<string, List<TickResultDataVO>> dayResultMap = 
                    CommonTool.ToDictionaryList(results, k => k.DateTime.ToString("yyyy_MM_dd"));

                foreach (string key in dayResultMap.Keys)
                {
                    ListToFile(dayResultMap[key]);
                }
            }
        }

        private void ListToFile(List<TickResultDataVO> results)
        {
            StringBuilder content = new StringBuilder();
            string name = results[0].Name;

            foreach (TickResultDataVO result in results)
            {
                int minSec = Convert.ToInt32(result.DateTime.ToString("HHmm"));
                if (minSec < 0815 || minSec > 1345)
                {
                    continue;
                }

                string data =
                    result.DateTime.ToString("yyyy/MM/dd") + "," +
                    result.DateTime.ToString("HH:mm") + "," +
                    result.Open + "," +
                    result.High + "," +
                    result.Low + "," +
                    result.Close + "," +
                    result.volume;
                content.AppendLine(data);
            }

            string path = targetPath + @"\" + name + @"\";
            string fileName = "Daily_" + results[0].DateTime.ToString("yyyy_MM_dd") + ".csv";

            if (content.Length > 0)
            {
                Console.WriteLine("output File => (" + name + ")" + fileName);

                content.Insert(0, "Date,Time,Open,High,Low,Close,Volume\n");
                CommonTool.StringToFile(path, fileName, content.ToString());
            }
        }

        //記錄group的資料
        Dictionary<string, List<TickDataVO>> groupMap = new Dictionary<string, List<TickDataVO>>();

        //結果，key:商品, value:分鐘資料
        Dictionary<string, List<TickResultDataVO>> groupResult = new Dictionary<string, List<TickResultDataVO>>();
        string beforeKey = null;
        /// <summary>
        /// 設定群組
        /// </summary>
        /// <param name="convert"></param>
        /// <param name="dateFormat"></param>
        /// <param name="group"></param>
        private void SetGroup(CSVLoadConvert convert)
        {
            string date = convert.Get<string>("成交日期").Trim();
            string productNo = convert.Get<string>("商品代號").Trim();
            string time = convert.Get<string>("成交時間").Trim();
            string timeMinute = time.Substring(0, 4);

            double price = convert.Get<double>("成交價格");
            int volume = convert.Get<int>("成交數量(B+S)");

            string key = productNo + "_" + timeMinute;

            if (!groupMap.ContainsKey(key))
            {
                if (groupMap.Count > 0)
                {
                    SetResult(groupMap[beforeKey]);//設定前一個key至result
                }
                groupMap.Add(key, new List<TickDataVO>());
                beforeKey = key;//記錄前一個key
            }

            groupMap[key].Add(new TickDataVO
            {
                Date = date,
                Name = productNo,
                Time = time,
                Time_Min = timeMinute,
                Price = price,
                Volume = volume,
            });
        }

        private void SetResult(List<TickDataVO> tickDatas)
        {
            if (tickDatas.Count == 0)
            {
                return;
            }

            TickDataVO tickData = tickDatas.OrderBy(o => o.Time).ToArray()[0];
            TickResultDataVO result = new TickResultDataVO() 
            {
                Name = tickData.Name,
                Low = 9999999,
                High = -9999999,
                Open = tickData.Price,
                
            };


            foreach (TickDataVO vo in tickDatas)
            {
                double price = vo.Price;
                if (price > result.High)
                {
                    result.High = price;
                }
                if (price < result.Low)
                {
                    result.Low = price;
                }

                result.DateTime = DateTime.ParseExact(tickData.Date + " " + tickData.Time_Min, "yyyyMMdd HHmm", CultureInfo.InvariantCulture);
                result.Close = price;
                result.volume = vo.Volume;
            }

            //設定
            if (!groupResult.ContainsKey(result.Name))
            {
                groupResult.Add(result.Name, new List<TickResultDataVO>());
            }
            groupResult[result.Name].Add(result);
        }
    }

    public class TickDataVO
    {
        public string Date { set; get; }
        public string Name { set; get; }
        public string Time { set; get; }
        public string Time_Min { set; get; }
        public double Price { set; get; }
        public int Volume { set; get; }
    }

    public class TickResultDataVO
    {
        public string Name { set; get; }
        public DateTime DateTime { set; get; }
        public double High { set; get; }
        public double Low { set; get; }
        public double Close { set; get; }
        public double Open { set; get; }
        public int volume { set; get; }
    }
}
