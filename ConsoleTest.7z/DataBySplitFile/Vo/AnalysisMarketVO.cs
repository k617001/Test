﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleTest.DataBySplitFile
{
    public class AnalysisMarketVO
    {
        public AnalysisMarketVO()
        {
            Date = new List<DateTime>();
            Open = new List<int>();
            High = new List<int>();
            Low = new List<int>();
            Close = new List<int>();
            Volume = new List<int>();
        }

        public List<DateTime> Date { set; get; }
        public List<int> Open { set; get; }
        public List<int> High { set; get; }
        public List<int> Low { set; get; }
        public List<int> Close { set; get; }
        public List<int> Volume { set; get; }
    }
}
