﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleTest.extandAAA
{
    public class NormalTest
    {
        public virtual void Aaaa()
        {
            Console.WriteLine("NormalTest");
        }
    }
}
