﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleTest.extandAAA
{
    class AAATest1 : NormalTest
    {
        public override void Aaaa()
        {
            Console.WriteLine("AAATest1");
        }
    }
}
