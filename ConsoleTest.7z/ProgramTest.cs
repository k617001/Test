﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace ConsoleTest
{
    public class ProgramTest
    {
        public string[] funcs = new string[] 
        {
            "GeneralTradingImport",
            "GeneralTradingSearch",
            "CentralizedCustomSearch",
            "CentralizedCustomImport",
        };

        public string[] emps = new string[] 
        {
"	cathy.zhou	C1034178	",
"	d1519195	D1519195	",
"	yeting.pang	D1700723	",
"	amy.liang	C1349824	",
"	C0700078	C0700078	",
"	c0900414	C0900414	",
"	zhihong.zhang	C1030546	",
"	betty.liang	C1005034	",
"	c1333583	C1333583	",
"	c1408906	C1408906	",
"	ivy.lin	C1213919	",
"	lisa.shao	C1624043	",
"	nolan.zhang	C0800249	",
"	pingping.zheng	C1009005	",
"	xianming.zeng	C1032082	",
"	yan.wang	C1031934	",
"	d1443510	D1443510	",
"	fannie.wu	D1302808	",
"	heaven.su	D1522638	",
"	yuejin.yuan	D1406817	",
"	caifeng.yang	D0662047	",
"	d1625062	D1625062	",
"	lei.zhou	D1359142	",
"	xiang.sheng	D1061012	",
"	xueying.chen	D1457969	",
"	yancui.wu	D1058103	",
"	zhen.cao	D0754037	",


        };

        public void Action()
        {
            StringBuilder result = new StringBuilder();
            foreach (string func in funcs)
            {
                foreach(string emp in emps) {
                    result.AppendLine(func + "\t" + emp);
                }
            }

            this.StringToFile(@"d:/aaa.txt", result.ToString());
        }

        public void StringToFile(string path, string content)
        {
            using (StreamWriter file = new StreamWriter(path, true))
            {
                file.WriteLine(content);
            }
        }
    }



}
