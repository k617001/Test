﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace ConsoleTest.DataTableTest
{
    class ImportRowDataTableTest
    {
        DataTable table2 = new DataTable();
        public void Action()
        {
            DataTable table1 = new DataTable();

            DataRow newDataRow = table1.NewRow();
            newDataRow["AAA"] = "A";

            table1.Rows.Add(newDataRow);

            Console.WriteLine(table1.Rows.Count);


            table2.ImportRow(newDataRow);   
            Console.WriteLine(table2.Rows.Count);
        }
    }
}
