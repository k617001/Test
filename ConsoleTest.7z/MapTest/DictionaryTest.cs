﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleTest.MapTest
{
    public class DictionaryTest
    {
        Dictionary<KeyObj, ValueObj> map = new Dictionary<KeyObj, ValueObj>();

        public void Action()
        {
            for (int i = 0; i < 10; i++ )
            {
                KeyObj key = new KeyObj()
                {
                    Key1 = i,
                    Key2 = i + 1
                };
                ValueObj value = new ValueObj()
                {
                    Value1 = i + 2,
                    Value2 = i + 3
                };

                map.Add(key, value);
            }

            int x = 100;
            KeyObj tkey = new KeyObj()
            {
                Key1 = x,
                Key2 = x + 1
            };
            KeyObj tkey2 = new KeyObj()
            {
                Key1 = x,
                Key2 = x + 1
            };
            ValueObj tValue = new ValueObj()
            {
                Value1 = x + 2,
                Value2 = x + 3
            };

            map.Add(tkey, tValue);
            map.Add(tkey2, tValue);
            ValueObj v = map[tkey];
        }
    }

    public class KeyObj
    {
        public int Key1 { set; get; }
        public int Key2 { set; get; }
    }

    public class ValueObj
    {
        public int Value1 { set; get; }
        public int Value2 { set; get; }
    }
}
