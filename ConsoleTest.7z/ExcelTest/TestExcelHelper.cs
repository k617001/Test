﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NPOI.SS.UserModel;
using CommonUtil.Helper.ExcelHelper;
using System.IO;

namespace ConsoleTest.ExcelTest
{
    public class TestExcelHelper
    {
        public void Action()
        {
            string path = @"D:\Test\TestExl.xlsx";


            ExcelReaderHelper helper = new ExcelReaderHelper();
            IWorkbook workbook = helper.SetWorkBook(path);

            ISheet sheet = workbook.GetSheetAt(0);
            helper.SetSheet(sheet);

            StringBuilder showStr = new StringBuilder();
            for (int row = 0; row < sheet.LastRowNum; row++)
            {
                showStr.Append(helper.CellValue.String() + ",");
                showStr.Append(helper.CellValue.String() + ",");
                showStr.Append(helper.CellValue.String() + ",");
                showStr.Append(helper.CellValue.String() + ",");
                showStr.Append(helper.CellValue.String() + ",");
                showStr.Append(helper.CellValue.String() + ",");
                helper.NextRow();

                Console.WriteLine(showStr);
                showStr.Clear();
            }
        }
    }
}
