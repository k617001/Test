﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleTest.QlearningTest
{
    public class Qlearning
    {
        double r = 0.8;
        int[,] reward = new int[6, 6] {
        { -1, -1, -1, -1, 0, -1 }, 
        { -1, -1, -1, 0, -1, 100 },
        { -1, -1, -1, 0, -1, -1 }, 
        { -1,  0,  0,-1,  0, -1 },
        {  0, -1, -1, 0, -1, 100 },
        { -1,  0, -1,-1,  0, 100 } };

        double[,] Q;




        public void Action(double r, int[,] reward)
        {
            this.r = r;
            this.reward = reward;

            Q = InitData(reward.GetUpperBound(0));

            int episode = 2000; //計算代數
            for (int i = 0; i < episode; i++)
            {
                var random = new Random();
                int getAction = random.Next(0, reward.GetUpperBound(0) + 1);
                var p = GetNextState(getAction);
                if (p.Count > 1)
                {
                    int getState = random.Next(0, p.Count);
                    SetupQ(p[getState]);
                }
                else
                    SetupQ(p[0]);
                Display(Q);
            }

            SearchQ(2);
            ShowAllInDictionary(Qmap);
        }

        /// <summary>
        /// 初始化
        /// </summary>
        /// <param name="size"></param>
        /// <returns></returns>
        private double[,] InitData(int size)
        {
            size++;
            double[,] q = new double[size, size];

            for (int row = 0; row < size; row++)
            {
                for (int column = 0; column < size; column++)
                {
                    q[row, column] = 0;
                }
            }
            return q;
        }

        /// <summary>
        /// 找出下個 state 最大值
        /// </summary>
        /// <param name="QList"></param>
        /// <returns></returns>
        private double Max(List<point> QList)
        {
            int Count = 0;
            double[] result = new double[QList.Count];
            foreach (point p in QList)
                result[Count++] = Q[p.x, p.y];

            return result.Max();
        }

        static Dictionary<point, int> map = new Dictionary<point, int>();
        static Dictionary<point, double> Qmap = new Dictionary<point, double>();

        public int Search(int Rx)
        {
            int result = 0;
            var pointComparer = new pointComparer();

            int i = 0;
            while (i <= reward.GetUpperBound(1))
            {
                result = reward[Rx, i];
                if (result != -1 &&
                    !map.Keys.Contains(new point() { x = Rx, y = i }, pointComparer))
                {
                    map.Add(new point() { x = Rx, y = i }, reward[Rx, i]);

                    if (result != 100)
                        result = Search(i);

                    if (result == 100)
                        return result;
                }

                i++;
            }

            return result;

        }

        /// <summary>
        /// 找最佳化路徑
        /// </summary>
        /// <param name="Rx"></param>
        /// <param name="Max"></param>
        /// <returns></returns>
        private double SearchQ(int Rx, double Max = 0)
        {
            double result = 0;
            var pointComparer = new pointComparer();

            int i = 0;
            while (i <= Q.GetUpperBound(1))
            {
                result = Q[Rx, i];
                if (result > Max &&
                    !map.Keys.Contains(new point() { x = Rx, y = i }, pointComparer))
                {
                    Qmap.Add(
                        new point() { x = Rx, y = i }, Q[Rx, i]);

                    Max = result;

                    result = SearchQ(i, Max);
                    if (result < Max)
                        return result;

                }

                i++;

            }
            return result;

        }

        /// <summary>
        /// 取得下一個樹狀節點數量
        /// </summary>
        /// <param name="Rx"></param>
        /// <returns>List<point></returns>
        private List<point> GetNextState(int Rx)
        {
            map.Clear();
            var record = new List<point>();
            var pointComparer = new pointComparer();
            for (int i = 0; i <= reward.GetUpperBound(1); i++)
            {
                if (reward[Rx, i] != -1 &&
                    !map.Keys.Contains(new point() { x = Rx, y = i }, pointComparer))
                {
                    map.Add(
                        new point() { x = Rx, y = i }, reward[Rx, i]);
                    record.Add(new point() { x = Rx, y = i });
                }

            }

            return record;
        }

        private void setupQ(int x, int y)
        {
            double result = reward[x, y] + r * Max(GetNextState(y));
        }

        /// <summary>
        /// 學習並寫入狀態
        /// </summary>
        /// <param name="p"></param>
        private void SetupQ(point p)
        {
            int x = p.x;
            int y = p.y;
            var s = GetNextState(y);
            double result = reward[x, y] + r * Max(s);
            Q[x, y] = System.Math.Round(result, 0, MidpointRounding.AwayFromZero); //四捨五入

        }
        /// <summary>
        /// 顯示字典全部內容
        /// </summary>
        /// <param name="MyDic"></param>
        private void ShowAllInDictionary(Dictionary<point, int> MyDic)
        {
            foreach (var OneItem in MyDic)
            {
                Console.WriteLine("Key = " + OneItem.Key.x + " " + OneItem.Key.y + ", Value = " + OneItem.Value);
            }
        }

        private void ShowAllInDictionary(Dictionary<point, double> MyDic)
        {
            foreach (var OneItem in MyDic)
            {
                Console.WriteLine("Key = " + OneItem.Key.x + " " + OneItem.Key.y + ", Value = " + OneItem.Value);
            }
        }
        private void SearchXInDictionary(Dictionary<point, int> MyDic, int x)
        {
            foreach (var OneItem in MyDic)
            {
                if (OneItem.Key.x == x)
                    Console.WriteLine("Key = " + OneItem.Key.x + " " + OneItem.Key.y + ", Value = " + OneItem.Value);
            }
        }

        private void SearchYInDictionary(Dictionary<point, int> MyDic, int y)
        {
            foreach (var OneItem in MyDic)
            {
                if (OneItem.Key.y == y)
                    Console.WriteLine("Key = " + OneItem.Key.x + " " + OneItem.Key.y + ", Value = " + OneItem.Value);
            }
        }

        private void Display(int[,] array)
        {
            for (int i = 0; i <= array.GetUpperBound(0); i++)
            {
                for (int ii = 0; ii <= array.GetUpperBound(1); ii++)
                {
                    Console.Write(array[i, ii] + " ");
                }
                Console.WriteLine();
            }

        }

        private void Display(double[,] array)
        {
            ConsoleColor color = Console.ForegroundColor;
            for (int i = 0; i <= array.GetUpperBound(0); i++)
            {
                for (int ii = 0; ii <= array.GetUpperBound(1); ii++)
                {
                    if (array[i, ii] > 0)
                        Console.ForegroundColor = ConsoleColor.Red;
                    int len = (array[i, ii].ToString()).Length;
                    string empty = string.Empty.PadRight(4 - len);
                    Console.Write(array[i, ii] + empty);
                    Console.ForegroundColor = color;

                }
                Console.WriteLine();
            }

            Console.WriteLine();
        }

        public class point
        {
            public int x = 0;
            public int y = 0;
        }

        public class pointComparer : IEqualityComparer<point>
        {
            public bool Equals(point x, point y)
            {
                return x.x == y.x && x.y == y.y;
            }

            public int GetHashCode(point x)
            {
                return x.x.GetHashCode() + x.y.GetHashCode();
            }


        }

    }

}
