﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace ConsoleTest.ThreadTest
{
    class StaticTest
    {

        private static List<int> _isDone = new List<int>();

        public void Action()
        {
            for (int i = 0; i < 30; i++)
            {
                Console.WriteLine("-----------" + i + "----------");
                _isDone.Clear();
                StaticTest.Main1(i);
                
            }
            
        }
        static void Main1(int firstId)
        {
            for (int i = 0; i < 10; i++ )
            {
                new Thread(() =>
                    {
                        Done(firstId, i);
                    }).Start();
            }
        }

        static void Done(int firstId, int id)
        {
            //Thread.Sleep(10);
            if (_isDone.Count == 0)
            {
                Console.WriteLine(id + ". Done(" + firstId + ") " + _isDone.Count);
                _isDone.Add(1); // 第二个线程来的时候，就不会再执行了(也不是绝对的，取决于计算机的CPU数量以及当时的运行情况)
                
            }
        }
    }
}
