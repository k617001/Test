﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using CommonUtil.Helper.CSVLoad;
using ConsoleTest.DataBySplitFile;
using System.Diagnostics;

namespace ConsoleTest.ThreadTest
{
    class ThreadTestAction
    {
        int loopCount = 100;
        int threadCount = 0;
        Random rnd = new Random(DateTime.Now.Millisecond);

        public void Action()
        {
            RunTime(TestRun1);
            RunTime(TestRun2);
        }

        private void RunTime(Action action)
        {
            Stopwatch sw = new Stopwatch();
            sw.Reset();
            sw = Stopwatch.StartNew();

            action();

            sw.Stop();
            TimeSpan el = sw.Elapsed;
            Console.WriteLine("花費 {0} ", el);
        }

        private void TestRun1()
        {
            Console.WriteLine("===============Normal For loop===============");
            for (int i = 0; i < loopCount; i++)
            {
                Run(i);
            }
        }

        private void TestRun2()
        {
            Console.WriteLine("==============Parallel.For================");
            Parallel.For(0, loopCount, i =>
            {
                Run(i);
            });
        }

        private void Run(int i)
        {
            threadCount++;
            Console.WriteLine("Start thread #{0} -> threadCount:{1} ", i, threadCount);
            int dataCount = DoSlicedJob();
            threadCount--;
            Console.WriteLine("Settoped Thread #{0} -> threadCount:{1} ", i, threadCount);
        }


        private int DoSlicedJob()
        {
            string filePath = RunAction.ALL_SOURCE_DATA;
            int dataCount = 0;
            CSVLoadHelper.LoadCsv(filePath, (row, convert) =>
            {
                dataCount++;
            });

            return dataCount;
        }


    }
}
