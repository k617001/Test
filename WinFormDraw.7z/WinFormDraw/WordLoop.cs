﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;
using System.ComponentModel;

namespace WinFormDraw
{
    /// <summary>
    /// 處理遊戲迴圈的行為
    /// </summary>
    public class WordLoop
    {
        Timer timer;
        WordAction wordAction = null;
        MainFormInfoVO mainVO = null;

        //開始座標
        int START_POS = 20;
        //結束座標，顯示元件方框寬度減的值
        int END_POS = 20;
        //結束線的寬度1~10
        int END_LINE_SIZE = 10;

        /// <summary>
        /// 外部定義分數的label
        /// </summary>
        public Label SourceLabel { set; get; }

        /// <summary>
        /// 外部提供的結束時觸發方法
        /// </summary>
        public Action GameOverAction { set; get; }

        /// <summary>
        /// 自訂等級
        /// </summary>
        public List<SourceLevel> SourceLevel { set; get; }

        public WordLoop(Control mainControl, IContainer components)
        {
            //計時器
            this.timer = new Timer(components);
            this.timer.Enabled = true;
            this.timer.Interval = 100;  /* 100 millisec */
            this.timer.Tick += new EventHandler(AllLoop);

            //預設等級
            SourceLevel = new List<SourceLevel>()
                {
                    new SourceLevel(0, 10, 3),
                    new SourceLevel(200, 15, 3),
                    new SourceLevel(400, 20, 3),
                    new SourceLevel(600, 23, 4),
                    new SourceLevel(900, 30, 3),
                    new SourceLevel(1000, 30, 4),
                };

            //相關屬性物件
            this.mainVO = new MainFormInfoVO()
            {
                Graphics = mainControl.CreateGraphics(),//畫圖元件
                Random = new Random(Guid.NewGuid().GetHashCode()),//亂數
                MainControl = mainControl,//主要控制項

                Start = START_POS,
                End = mainControl.Width - END_POS,//結束遊戲的判斷

                MaxHeight = mainControl.Height,
                MaxWidth = mainControl.Width

            };

            this.wordAction = new WordAction(mainVO);

        }

        /// <summary>
        /// 取得分數
        /// </summary>
        /// <returns></returns>
        public int GetSource()
        {
            return this.wordAction.Source;
        }

        /// <summary>
        /// 刪除字元
        /// </summary>
        /// <param name="key"></param>
        public void DelWord(string keyInWord)
        {
            this.wordAction.SaveDelWord(keyInWord);
        }

        /// <summary>
        /// 遊戲開始
        /// </summary>
        public void GameStart()
        {
            this.timer.Enabled = true;
            this.wordAction.GameStart();
            this.wordAction.Source = 0;
        }

        /// <summary>
        /// 最大的迴圈(所有物件的行為)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AllLoop(object sender, EventArgs e)
        {
            //每次移動2
            this.wordAction.MoveX(2);

            //刪除已被記錄的字元
            this.wordAction.DelWords();
            if (SourceLabel != null)
            {
                SourceLabel.Text = this.wordAction.Source.ToString();
            }

            //重繪
            this.mainVO.MainControl.Invalidate();

            //亂字產生字
            SetLevel();

            //結束遊戲的判斷
            if (this.wordAction.IsOver())
            {
                this.timer.Enabled = false;
                if (this.GameOverAction != null)
                {
                    this.GameOverAction();
                }
            }
        }

        /// <summary>
        /// 設定產生字的等級
        /// </summary>
        private void SetLevel()
        {
            int source = this.wordAction.Source;
            SourceLevel level = this.SourceLevel
                .Where(w => source >= w.Source)
                .Last()
                ;
            this.wordAction.RandomAddWord(level.WordPercent, level.NextMaxWordCount);
        }

        /// <summary>
        /// 繪圖
        /// </summary>
        public void Draw()
        {
            this.wordAction.DrawWord();
            this.DrawOtherView();
        }


        /// <summary>
        /// 畫其他的view
        /// </summary>
        /// <param name="mainVO"></param>
        public void DrawOtherView()
        {
            //畫結束線
            using (Pen endPen = new Pen(Color.Red, this.END_LINE_SIZE))
            {
                mainVO.Graphics.DrawLine(endPen, mainVO.End, 0, mainVO.End, mainVO.MaxHeight);
            }
            
        }
    }
}
