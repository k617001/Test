﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

namespace WinFormDraw
{
    public class MainFormInfoVO
    {
        public Control MainControl { set; get; }
        public Graphics Graphics { set; get; }
        public Random Random { set; get; }

        public int Start { set; get; }
        public int End { set; get; }
        public int MaxWidth { set; get; }
        public int MaxHeight { set; get; }
    }
}
