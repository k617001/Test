﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WinFormDraw
{
    /// <summary>
    /// 重覆使用物件池
    /// </summary>
    public class WordVoPool
    {
        List<WordVO> pool = new List<WordVO>();

        /// <summary>
        /// 建立新的物件
        /// </summary>
        /// <param name="mainInfoVO"></param>
        /// <returns></returns>
        public WordVO New_WordVO(MainFormInfoVO mainInfoVO)
        {
            if(pool.Count == 0) 
            {
                return new WordVO(mainInfoVO);
            }

            WordVO rtnVO = pool[0];
            pool.Remove(rtnVO);

            return rtnVO;
        }

        /// <summary>
        /// 回收物件
        /// </summary>
        /// <param name="vo"></param>
        public void Recycling(WordVO vo)
        {
            vo.Init();
            pool.Add(vo);
        }

        /// <summary>
        /// 回收物件
        /// </summary>
        /// <param name="vo"></param>
        public void Recyclings(IEnumerable<WordVO> vos)
        {
            foreach(WordVO vo in vos) 
            {
                this.Recycling(vo);
            }
        }
    }
}
