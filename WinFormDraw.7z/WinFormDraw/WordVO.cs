﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

namespace WinFormDraw
{
    /// <summary>
    /// 字的物件
    /// </summary>
    public class WordVO
    {
        int x = 0;
        int y = 0;
        public bool Enable { set; get; }
        public string ShowChar { set; get; }

        MainFormInfoVO mainInfoVO;
        public WordVO(MainFormInfoVO mainInfoVO)
        {
            this.mainInfoVO = mainInfoVO;
            this.Init();
        }

        /// <summary>
        /// 初始化字
        /// </summary>
        string words = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        public void Init()
        {
            this.Enable = true;
            Random random = mainInfoVO.Random;
            Control control = mainInfoVO.MainControl;

            this.x = 10;
            this.y = random.Next(10, control.Height - 20);//顯示字的位置

            this.ShowChar = words[random.Next(0, words.Length)].ToString();
        }

        /// <summary>
        /// 取得x座標
        /// </summary>
        /// <returns></returns>
        public int GetX()
        {
            return x;
        }

        /// <summary>
        /// 取得y座標
        /// </summary>
        /// <returns></returns>
        public int GetY()
        {
            return y;
        }

        /// <summary>
        /// 移動X
        /// </summary>
        /// <param name="x"></param>
        public void MoveX(int x)
        {
            this.x += x;
        }

        /// <summary>
        /// 移動Y
        /// </summary>
        /// <param name="y"></param>
        public void MoveY(int y)
        {
            this.y += y;
        }

        /// <summary>
        /// 畫字
        /// </summary>
        public void Draw()
        {
            if (!this.Enable)
            {
                return;
            }

            Font font = new Font("Arial", 10);
            mainInfoVO.Graphics.DrawString(this.ShowChar, font, Brushes.Black, this.x, this.y);
        }
    }
}
