﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace WinFormDraw
{
    public partial class Form1 : Form
    {
        WordLoop move = null;
        public Form1()
        {
            InitializeComponent();

            this.move = new WordLoop(this.panel1, this.components);
            this.move.GameOverAction = this.GameOverShow;
            this.move.SourceLabel = this.sourceLabel;
            //預設等級-測試用
            this.move.SourceLevel = new List<SourceLevel>()
            {
                new SourceLevel(0, 10, 3),
                new SourceLevel(1, 15, 3),
                new SourceLevel(2, 80, 10),
            };

        /// <summary>
        /// 遊戲結束時執行的方法
        /// </summary>
        private void GameOverShow()
        {
            MessageBox.Show("Game Over!!\n分數: " + this.move.GetSource());
        }

        /// <summary>
        /// 繪圖觸發
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            this.move.Draw();
        }

        /// <summary>
        /// 輸入字元,因為panel不能設定，所以用textbox來執行
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            string key = e.KeyChar.ToString().ToUpper();
            this.move.DelWord(key);
            this.textBox1.Text = string.Empty;
        }

        /// <summary>
        /// 開始
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            this.move.GameStart();
            this.textBox1.Focus();
        }
    }
}
