﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WinFormDraw
{
    public class SourceLevel
    {

        public SourceLevel()
        {
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="source">分數</param>
        /// <param name="wordPercent">出字的頻率</param>
        /// <param name="nextMaxWordCount">每次出字的個數,1~設定的值(亂數出字)</param>
        public SourceLevel(int source, int wordPercent, int nextMaxWordCount)
        {
            this.Source = source;
            this.WordPercent = wordPercent;
            this.NextMaxWordCount = nextMaxWordCount;
        }

        /// <summary>
        /// 分數
        /// </summary>
        public int Source { set; get; }

        /// <summary>
        /// 出字的頻率
        /// </summary>
        public int WordPercent { set; get; }

        /// <summary>
        /// 每次出字的個數,1~設定的值(亂數出字)
        /// </summary>
        public int NextMaxWordCount { set; get; }
    }
}
