﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace WinFormDraw
{
    /// <summary>
    /// 處理字元的行為
    /// </summary>
    public class WordAction
    {
        //亂key時扣的分數
        int DEDUCTION_POINT = 5;

        public int Source { set; get; }

        List<WordVO> allWordVOs = new List<WordVO>();
        List<WordVO> delWordVOs = new List<WordVO>();

        WordVoPool wordVoPool;
        MainFormInfoVO mainInfoVO;
        public WordAction(MainFormInfoVO mainInfoVO)
        {
            this.mainInfoVO = mainInfoVO;
            this.wordVoPool = new WordVoPool();
        }

        /// <summary>
        /// 亂數比例新增字
        /// </summary>
        public void RandomAddWord(int percent, int maxWordNum)
        {
            Random r = mainInfoVO.Random;
            int rP = r.Next(1, 100);

            if (percent < rP)
            {
                return;
            }

            int maxWord = r.Next(1, maxWordNum);
            for (int i = 0; i < maxWord; i++ )
            {
                //用pool產生字元物件
                allWordVOs.Add(this.wordVoPool.New_WordVO(mainInfoVO));
            }

        }

        /// <summary>
        /// 記錄要刪除的字元
        /// </summary>
        /// <param name="delWord"></param>
        public void SaveDelWord(string delWord)
        {
            this.WordLoop(vo =>
            {
                if (!vo.ShowChar.Equals(delWord))
                {
                    return;
                }
                vo.Enable = false;
                delWordVOs.Add(vo);
            });

            ///亂key時扣分
            if (delWordVOs.Count == 0 && this.Source > 0)
            {
                this.Source -= DEDUCTION_POINT;
                if (this.Source <= 0)
                {
                    this.Source = 0;
                }
            }
        }

        /// <summary>
        /// 重繪時刪除的字元
        /// </summary>
        /// <param name="delWord"></param>
        public void DelWords()
        {
            foreach(WordVO delVO in this.delWordVOs) 
            {
                allWordVOs.Remove(delVO);

                //回收vo
                this.wordVoPool.Recycling(delVO);
            }
            //記錄分數
            this.Source += this.delWordVOs.Count;
            this.delWordVOs.Clear();
        }

        /// <summary>
        /// 初始值
        /// </summary>
        public void Init()
        {
            this.WordLoop(vo => vo.Init());
        }

        /// <summary>
        /// 移動x軸
        /// </summary>
        /// <param name="x"></param>
        public void MoveX(int x)
        {
            this.WordLoop(vo => vo.MoveX(x));
        }

        /// <summary>
        /// 移動y軸
        /// </summary>
        /// <param name="x"></param>
        public void MoveY(int y)
        {
            this.WordLoop(vo => vo.MoveX(y));
        }

        /// <summary>
        /// 遊戲開始
        /// </summary>
        public void GameStart()
        {
            this.isOver = false;
            this.wordVoPool.Recyclings(this.allWordVOs);//回收物件
            this.allWordVOs.Clear();
        }

        /// <summary>
        /// 是否結束遊戲
        /// </summary>
        /// <returns></returns>
        bool isOver = false;
        public bool IsOver()
        {
            if (isOver)
            {
                return isOver;
            }

            this.WordLoop(vo => {
                if ((vo.GetX() >= this.mainInfoVO.End) && !isOver)
                {
                    isOver = true;
                }
            });
            return isOver;
        }

        /// <summary>
        /// 重畫字
        /// </summary>
        public void DrawWord()
        {
            this.WordLoop(vo => vo.Draw());
        }

        /// <summary>
        /// 所有字元的迴圈，減少程式碼的共用
        /// </summary>
        /// <param name="wordAction"></param>
        private void WordLoop(Action<WordVO> wordAction)
        {
            foreach (WordVO vo in allWordVOs)
            {
                wordAction(vo);
            }
        }
    }
}
