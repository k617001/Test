﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BDoor.ValueObject;
using BDoor.EnumType;

namespace BDoor.DataObject
{
    public class FindData
    {
        /// <summary>
        /// 查詢均線
        /// </summary>
        /// <returns></returns>
        public AvgLineVO FindAvgLine()
        {
            return new AvgLineVO()
            {
            };
        }

        public SecPointVO FindNowPoint()
        {
            return new SecPointVO()
            {
                Point = 10002,
                Volume = 20
            };
        }

        /// <summary>
        /// 查詢目前擁有的
        /// </summary>
        /// <returns></returns>
        public SelfVO FindSelf()
        {
            return new SelfVO()
            {

            };
        }



        /// <summary>
        /// 買進
        /// </summary>
        public void SellBuy(SelfVO selfVO)
        {
            if (selfVO.TransType == BuySellType.SELL)
            {
                this.Buy(selfVO);
            }
            else
            {
                this.Sell(selfVO);
            }
        }

        /// <summary>
        /// 買進
        /// </summary>
        public void Buy(SelfVO selfVO)
        {

        }

        /// <summary>
        /// 平倉
        /// </summary>
        public void Sell(SelfVO selfVO)
        {

        }

        /// <summary>
        /// 買進
        /// </summary>
        public void Buy()
        {

        }

        /// <summary>
        /// 平倉
        /// </summary>
        public void Sell()
        {

        }
    }
}
