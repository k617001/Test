﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BDoor.ValueObject;

namespace BDoor.DataObject
{
    /// <summary>
    /// 記錄當天狀態的容器
    /// </summary>
    public class ContainerData
    {
        List<SecPointVO> setPoints;
        List<SecPointVO> set1MinPoints;
        List<SecPointVO> set5MinPoints;
        List<SecPointVO> Min30AM;

        /// <summary>
        /// 停利點
        /// </summary>
        public SecPointVO StopEarnPoint { set; get; }

        public SecPointVO Now30AM { set; get; }
        /// <summary>
        /// 前一分鐘的close值，來判斷訊號有沒有打到
        /// </summary>
        public SecPointVO Before1MinClose { set; get; }
        public ContainerData()
        {
            this.setPoints = new List<SecPointVO>();
            this.set1MinPoints = new List<SecPointVO>();
            this.set5MinPoints = new List<SecPointVO>();
            this.Min30AM = new List<SecPointVO>();
        }

        /// <summary>
        /// 記錄每秒報價
        /// </summary>
        /// <param name="secPointVO"></param>
        public void Add(SecPointVO secPointVO)
        {
            this.setPoints.Add(secPointVO);
        }

        /// <summary>
        /// 記每分鐘close
        /// 記錄30分k
        /// </summary>
        /// <param name="secPointVO"></param>
        public void Add1Min(SecPointVO secPointVO)
        {
            this.Before1MinClose = this.set1MinPoints.Last();
            this.set1MinPoints.Add(secPointVO);

            //計算30分K
            int am30 = 30;
            if (this.set1MinPoints.Count >= am30 && this.set1MinPoints.Count % am30 == 0)
            {
                double point = 0;
                double volume = 0;

                for (int i = this.set1MinPoints.Count - 1; i > 0; i--)
                {
                    SecPointVO vo = this.set1MinPoints[i];
                    point += vo.Point;
                    volume += vo.Volume;
                }
                //記錄目前的30k線
                this.Now30AM = new SecPointVO()
                {
                    Point = Math.Round(point / am30, 0),
                    Volume = (int)Math.Round(volume / am30, 0),
                };
                this.Min30AM.Add(this.Now30AM);
            }
        }

        /// <summary>
        /// 記録每五分鐘報價close
        /// </summary>
        /// <param name="secPointVO"></param>
        public void Add5Min(SecPointVO secPointVO)
        {
            this.set5MinPoints.Add(secPointVO);
        }
    }
}
