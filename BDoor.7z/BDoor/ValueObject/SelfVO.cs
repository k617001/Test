﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BDoor.EnumType;

namespace BDoor.ValueObject
{
    /// <summary>
    /// 目前已買進的口數
    /// </summary>
    public class SelfVO
    {
        //設定損失幾點出場
        int STOP_LESS_POINT = 100;
        //停利點
        int STOP_EARN_POINT = 80;

        public string Id { set; get; }
        /// <summary>
        /// 做空做多狀態
        /// </summary>
        public BuySellType TransType { set; get; }

        /// <summary>
        /// 交易點數
        /// </summary>
        public double TransPoint { set; get; }

        /// <summary>
        /// 一共買幾口
        /// </summary>
        public int Count { set; get; }

        /// <summary>
        /// 是否到停損範圍
        /// </summary>
        /// <returns></returns>
        public bool IsStopLess(double nowPoint)
        {
            if (this.TransType == BuySellType.BUY &&
                (nowPoint <= TransPoint - STOP_LESS_POINT   //停損
                        || nowPoint >= TransPoint + STOP_EARN_POINT)) //停利
            {
                return true;
            }
            if (this.TransType == BuySellType.SELL &&
                (nowPoint >= TransPoint + STOP_LESS_POINT    //停損
                        || nowPoint <= TransPoint + STOP_EARN_POINT)) //停利
            {
                return true;
            }

            return false;
        }
    }
}
