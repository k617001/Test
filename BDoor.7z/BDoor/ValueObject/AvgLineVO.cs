﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BDoor.ValueObject
{
    public class AvgLineVO
    {
        public double DayLine_5 { set; get; }
        public double DayLine_20 { set; get; }


        public double DayLineVol_5 { set; get; }
        public double DayLineVol_20 { set; get; }
    }
}
