﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BDoor.ValueObject
{
    /// <summary>
    /// 每秒的點數及成交量
    /// </summary>
    public class SecPointVO
    {
        public double Point { set; get; }

        public int Volume { set; get; }
    }
}
