﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BDoor.DataObject;
using BDoor.ValueObject;
using System.Globalization;
using BDoor.EnumType;

namespace BDoor
{
    public partial class Form1 : Form
    {
        FindData dao = null;
        AvgLineVO avgLineVO = null;
        ContainerData containData = null;
        public Form1()
        {
            InitializeComponent();
            Init();
        }

        public void Init()
        {
            //與api溝通放此-要資料下單
            this.dao = new FindData();
            this.containData = new ContainerData();
            //取得均線
            this.avgLineVO = dao.FindAvgLine();
            secTimer.Enabled = true;
        }

        /// <summary>
        /// 依時間判斷是否要執行
        /// </summary>
        /// <returns></returns>
        private bool IsTimeStart(string startTimeStr, string endTimeStr)
        {
            string today = DateTime.Now.ToString("yyyy/MM/dd ");
            DateTime startTime = DateTime.ParseExact(today + startTimeStr, "yyyy/MM/dd HH:mm", DateTimeFormatInfo.InvariantInfo);
            DateTime endTime = DateTime.ParseExact(today + endTimeStr, "yyyy/MM/dd HH:mm", DateTimeFormatInfo.InvariantInfo);
            if (DateTime.Now < startTime || DateTime.Now > endTime)
            {

                minute1Timer.Enabled = false;
                minute5Timer.Enabled = false;
                minute1Timer.Stop();
                minute5Timer.Stop();
                return false;
            }

            minute1Timer.Enabled = true;
            minute5Timer.Enabled = true;
            minute1Timer.Start();
            minute5Timer.Start();
            return true;
        }

        /// <summary>
        /// 計時器，每秒記報價
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void secTimer_Tick(object sender, EventArgs e)
        {
            if (IsTimeStart("08:30", "13:30"))
            {
                return;
            }


            SecPointVO secPoint = this.dao.FindNowPoint();
            this.containData.Add(secPoint);




            //查詢目前手上的
            SelfVO selfVO = this.dao.FindSelf();
            if (selfVO == null)
            {
                //入場
                InTo(secPoint, selfVO);
                return;
            }
            else
            {
                //出場
                Out(secPoint, selfVO);
            }

        }

        /// <summary>
        /// 計時器，每分鐘處理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void minuteTimer_Tick(object sender, EventArgs e)
        {
            //執行時間判斷
            if (IsTimeStart("09:00", "13:30"))
            {
                return;
            }
            SecPointVO closePoint = this.dao.FindNowPoint();
            this.containData.Add1Min(closePoint);
        }

        private void InTo(SecPointVO secPoint, SelfVO selfVO)
        {
            //判斷成交量，未超過均值不處理
            if (secPoint.Volume < avgLineVO.DayLineVol_5 && secPoint.Volume < avgLineVO.DayLineVol_20)
            {
                return;
            }

            //判斷目前是否經過交叉點
            //不在區間內就離開
            if (secPoint.Point < avgLineVO.DayLineVol_5 && secPoint.Point > avgLineVO.DayLineVol_20)
            {
                return;
            }


            SecPointVO am30 = this.containData.Now30AM;
            SecPointVO before1MinClose = this.containData.Before1MinClose;
            if (am30.Point > selfVO.TransPoint)//做空
            {
                dao.Sell();
            }
            else //做多
            {
                dao.Buy();
            }
        }

        private void Out(SecPointVO secPoint, SelfVO selfVO)
        {
            //停損點到馬上出場
            if (selfVO.IsStopLess(secPoint.Point))
            {
                this.dao.SellBuy(selfVO);
            }

        }


        /// <summary>
        /// 計時器，每五分鐘處理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void minute5Timer_Tick(object sender, EventArgs e)
        {
            SecPointVO secPoint = this.dao.FindNowPoint();
            this.containData.Add5Min(secPoint);


            //查詢目前手上的
            SelfVO selfVO = this.dao.FindSelf();

            if (selfVO != null)
            {
                return;
            }
            //分析頻率和斜率
            
        }
    }
}
