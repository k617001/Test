﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace BDoor
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            this.timer1.Start();
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            string now = DateTime.Now.ToString("HH:mm:ss");
            textBox1.AppendText(now + "- timer2_Tick" + System.Environment.NewLine);
            this.timer3.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            string now = DateTime.Now.ToString("HH:mm:ss");
            textBox1.AppendText(now + "- timer1_Tick" + System.Environment.NewLine);
            this.timer2.Start();
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            string now = DateTime.Now.ToString("HH:mm:ss");
            textBox1.AppendText(now + "- timer3_Tick" + System.Environment.NewLine);
        }
    }
}
