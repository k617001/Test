﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BatchJob.Interface;
using BatchJob.Job.Test;

namespace BatchJob.Register
{
    public class CommandRegister
    {
        private static Dictionary<string, IJob> jobMap = new Dictionary<string, IJob>();

        public static IJob GetJob(string command)
        {
            return jobMap[command];
        }

        public static bool isHasJob(string command)
        {
            return jobMap.ContainsKey(command);
        }

        public static void Register() 
        {
            jobMap.Add("TestJob", new TestJob());
        }
    }
}
