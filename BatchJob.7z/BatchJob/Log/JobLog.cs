﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BatchJob.Log
{
    public class JobLog
    {

        public void Insert(JobLogEntity entity)
        {
            //insert log
        }
    }
}
