﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BatchJob.Log
{
    public class JobLogEntity
    {
        public string JobName { set; get; }
        public DateTime StartTime { set; get; }
        public DateTime EndTime { set; get; }
        public int RunSec { set; get; }
        public bool IsError { set; get; }
        public string ExceptionMessage { set; get; }
    }
}
