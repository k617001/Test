﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BatchJob.Interface;

namespace BatchJob.Job.Test
{
    public class TestJob : IJob
    {

        public void Run()
        {
            Console.WriteLine(this.GetType().Name);
        }
    }
}
