﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BatchJob.Register;
using System.Diagnostics;
using BatchJob.Log;

namespace BatchJob
{
    public class Program
    {
        static void Main(string[] args)
        {
            Program program = new Program();
            program.Action(args);
        }

        public void Action(string[] commands)
        {
            if (commands.Length < 1)
            {
                return;
            }

            string jobName = commands[0];
            CommandRegister.Register();
            if (!CommandRegister.isHasJob(jobName))
            {
                return;
            }

            //log記錄
            JobLog jobLog = new JobLog();
            JobLogEntity logEntity = new JobLogEntity()
            {
                JobName = jobName,
                IsError = false,
                StartTime = DateTime.Now,
            };

            Console.WriteLine("Job Running....");
            try
            {
                CommandRegister.GetJob(jobName).Run();
            }
            catch(Exception e) {
                //記錄錯誤
                logEntity.IsError = true;
                logEntity.ExceptionMessage = e.Message + "\n" + e.StackTrace;
                jobLog.Insert(logEntity);
                return;
            }
            

            //結束時間
            logEntity.EndTime = DateTime.Now;
            logEntity.RunSec = ((TimeSpan)(logEntity.EndTime - logEntity.StartTime)).Seconds;

            //記錄至log
            jobLog.Insert(logEntity);
        }
    }
}
