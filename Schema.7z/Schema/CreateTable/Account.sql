﻿create Account{
	xxx char(1)
}