﻿create Account2{
	xxx char(1)
}