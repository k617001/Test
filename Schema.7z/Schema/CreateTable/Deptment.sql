﻿create Deptment{
	xxx char(1)
}