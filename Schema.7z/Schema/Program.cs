﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Schema.Action;

namespace Schema
{
    class Program
    {
        static void Main(string[] args)
        {
            AutoMaintainSchema schema = new AutoMaintainSchema();
            schema.Action();
        }
    }
}
