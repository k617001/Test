﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Resources;
using System.Globalization;
using Schema.CreateTable;
using System.Collections;
using Schema.AlterTable;
using Schema.DefaultData;

namespace Schema.Action
{
    public class AutoMaintainSchema
    {
        List<Type> resorceTypes = new List<Type>()
        {
            typeof(CreateTableResource),
            typeof(AlterTableResource),
            typeof(DefaultDataResource),
        };

        public void Action()
        {

            foreach (Type resourceType in resorceTypes)
            {
                ResourceManager manager = new ResourceManager(resourceType);

                Console.WriteLine("\n\n\n" + "************************* " + resourceType.Name + " *************************");

                ResourceSet resourceSet = manager.GetResourceSet(CultureInfo.CurrentUICulture, true, true);
                foreach (DictionaryEntry rs in resourceSet)
                {
                    string resourceKey = rs.Key.ToString();
                    string script = rs.Value.ToString();


                    Console.WriteLine("\n\nTable====>" + resourceKey);
                    Execute(script);
                }
            }

        }

        private void Execute(string statement)
        {
            Console.WriteLine("run =>\n" + statement);
        }
    }
}
