﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using NPOI.SS.UserModel;

namespace CommonUtil.Helper.ExcelHelper.ExcelVaild
{
    /// <summary>
    /// 匯入excel時做的驗証
    /// </summary>
    public class ExcelValidHelper
    {
        ExcelVaildResult vaildResult = null;
        List<ExcelColumnValid> validColumn = new List<ExcelColumnValid>();
        ExcelReaderHelper readerHelper;
        bool isRowAllNull = true;
        int startRow = 1;

        public ExcelValidHelper(ExcelReaderHelper readerHelper)
        {
            this.readerHelper = readerHelper;
            this.vaildResult = new ExcelVaildResult();
        }

        /// <summary>
        /// 設定驗証項目
        /// </summary>
        /// <param name="vaildColumn"></param>
        public ExcelValidHelper SetColumnValid(IEnumerable<ExcelColumnValid> vaildColumn)
        {
            this.validColumn.AddRange(vaildColumn);
            return this;
        }

        /// <summary>
        /// 設定要開始驗証的Row index
        /// 預設為1
        /// </summary>
        /// <param name="startRow"></param>
        /// <returns></returns>
        public ExcelValidHelper SetStartRow(int startRow)
        {
            this.startRow = startRow;
            return this;
        }

        /// <summary>
        /// 設定 全為空時是否跳過
        /// 預設true
        /// </summary>
        public ExcelValidHelper SetIsRowAllNull(bool isNull)
        {
            this.isRowAllNull = isNull;
            return this;
        }

        /// <summary>
        /// 實際驗証
        /// </summary>
        public ExcelValidHelper Validation()
        {
            ISheet sheet = this.readerHelper.GetSheet();
            for (int row = 1; row <= sheet.LastRowNum; row++)
            {
                //整個row都為空時跳過
                if (isRowAllNull && this.IsRowAllCellNull(row))
                {
                    continue;
                }

                for (int cell = 0; cell < validColumn.Count; cell++)
                {
                    //取得驗証物件
                    ExcelColumnValid vaildObj = validColumn[cell];
                    this.VaildCell(row, vaildObj.CellIndex, vaildObj);
                }
            }

            //還原位置
            readerHelper.SetRowCellIndex(0, 0);


            return this;
        }

        /// <summary>
        /// 結果
        /// </summary>
        /// <returns></returns>
        public ExcelVaildResult Result()
        {
            return this.vaildResult;
        }

        /// <summary>
        /// 整列是否為null
        /// 判斷使用
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        private bool IsRowAllCellNull(int row)
        {
            ISheet sheet = this.readerHelper.GetSheet();
            if (sheet.GetRow(row) == null)
            {
                return true;
            }

            for (int cell = 0; cell <= sheet.GetRow(row).LastCellNum; cell++)
            {
                readerHelper.SetRowCellIndex(row, cell);
                string valueStr = readerHelper.CellValue.String();

                if (!string.IsNullOrEmpty(valueStr))
                {
                    return false;
                }
            }
            return true;
        }

        /// <summary>
        /// 驗証欄位
        /// </summary>
        /// <param name="row"></param>
        /// <param name="cell"></param>
        private void VaildCell(int row, int cell, ExcelColumnValid vaildObj)
        {
            //設定目前的座標
            readerHelper.SetRowCellIndex(row, cell);

            //取得值
            ExcelReaderValueCell cellValue = readerHelper.CellValue;
            string valueStr = cellValue.String();
            
            //驗証是否可空值
            if (vaildObj.IsNull && string.IsNullOrEmpty(valueStr))
            {
                this.SetMessage(row, cell, vaildObj, "為必填欄位");
            }

            //驗證是否有重覆的資料
            if (vaildObj.IsExist && vaildObj.IsExistValue(valueStr))
            {
                this.SetMessage(row, cell, vaildObj, "資料已重覆");
            }

            string customErrorMsg = string.Empty;
            //驗証型別是否正確
            try
            {

                if (vaildObj.Type == typeof(string))
                {
                    customErrorMsg = this.CustomFuncVaild(vaildObj, valueStr);
                }
                else if (vaildObj.Type == typeof(DateTime))
                {
                    DateTime valueDate = cellValue.DateTime();
                    customErrorMsg = this.CustomFuncVaild(vaildObj, valueDate);
                }
                else if (vaildObj.Type == typeof(long))
                {
                    long valueLong = cellValue.Long();
                    customErrorMsg = this.CustomFuncVaild(vaildObj, valueLong);
                }
                else if (vaildObj.Type == typeof(int))
                {
                    int valueInt = cellValue.Int();
                    customErrorMsg = this.CustomFuncVaild(vaildObj, valueInt);
                }
                else if (vaildObj.Type == typeof(double))
                {
                    double valueDouble = cellValue.Double();
                    customErrorMsg = this.CustomFuncVaild(vaildObj, valueDouble);
                }
            }
            catch(Exception e) {
                this.SetMessage(row, cell, vaildObj, "型別錯誤，應為 " + vaildObj.Type.Name);
            }

            if (!string.IsNullOrEmpty(customErrorMsg))
            {
                this.SetMessage(row, cell, vaildObj, customErrorMsg);
            }
        }


        /// <summary>
        /// 執行自動驗証
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="vaildObj"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        private string CustomFuncVaild<T>(ExcelColumnValid vaildObj, T value)
        {
            if (vaildObj.CustomFunc == null)
            {
                return string.Empty;
            }

            object result = vaildObj.CustomFunc.DynamicInvoke(value);
            return result == null ? null : result.ToString();
        }

        /// <summary>
        /// 設定錯誤訊息
        /// </summary>
        /// <param name="row"></param>
        /// <param name="cell"></param>
        /// <param name="vaildObj"></param>
        /// <param name="errorMessage"></param>
        private void SetMessage(int row, int cell, ExcelColumnValid vaildObj, string errorMessage)
        {
            this.vaildResult.IsError = true;
            this.vaildResult.VaildDetails.Add(new ExcelVaildResultInfo()
            {
                Name = vaildObj.Name,
                ErrorMessage = errorMessage,
                Row = row,
                Cell = cell,
                CellStr = GetCellIdxStr(cell),
            });
        }

        /// <summary>
        /// cell轉成實際座標
        /// </summary>
        /// <param name="cellIndex"></param>
        /// <returns></returns>
        public string GetCellIdxStr(int cellIndex)
        {
            string cellStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

            int char1Idx = (int)Math.Floor((double)(cellIndex / cellStr.Length));
            int char2Idx = (int)cellIndex % cellStr.Length;

            string char1 = char1Idx == 0 ? "" : cellStr[char1Idx - 1] + "";

            return char1 + cellStr[char2Idx];
        }
    }

}
