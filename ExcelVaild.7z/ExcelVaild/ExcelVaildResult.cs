﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CommonUtil.Helper.ExcelHelper.ExcelVaild
{
    public class ExcelVaildResult
    {
        public ExcelVaildResult()
        {
            VaildDetails = new List<ExcelVaildResultInfo>();
        }

        public bool IsError { set; get; }

        public List<ExcelVaildResultInfo> VaildDetails { set; get; }
    }

    /// <summary>
    /// 錯誤訊息資訊
    /// </summary>
    public class ExcelVaildResultInfo
    {
        /// <summary>
        /// 欄位名稱
        /// </summary>
        public string Name { set; get; }
        /// <summary>
        /// 座標
        /// </summary>
        public string Pos { get { return CellStr.ToString() + (this.Row+1); } }
        /// <summary>
        /// row
        /// </summary>
        public int Row { set; get; }
        /// <summary>
        /// row用ABCD表示
        /// </summary>
        public string CellStr { set; get; }
        /// <summary>
        /// cell
        /// </summary>
        public int Cell { set; get; }

        /// <summary>
        /// 錯誤訊息
        /// </summary>
        public string ErrorMessage { set; get; }


        /// <summary>
        /// 完整的錯誤訊息
        /// </summary>
        public string ErrorMessageALL { 
            get {
                return Pos + " - " + Name + " " + ErrorMessage;
                
            } 
        }


    }

}
