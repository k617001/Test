﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CommonUtil.Helper.ExcelHelper.ExcelVaild
{
    public class ExcelColumnValid
    {
        Type setType = typeof(string);
        public Type Type {
            set { this.setType = value; }
            get { return this.setType; }
        }
        /// <summary>
        /// 欄位名稱
        /// </summary>
        public string Name { set; get; }

        /// <summary>
        /// 備註欄位，無作用
        /// </summary>
        public string Remark { set; get; }

        /// <summary>
        /// 欄位cell index
        /// </summary>
        public int CellIndex { set; get; }

        /// <summary>
        /// 是否可空值
        /// </summary>
        public bool IsNull { set; get; }

        /// <summary>
        /// 是否可重覆
        /// </summary>
        public bool IsExist { set; get; }

        /// <summary>
        /// 自訂驗証方法
        /// </summary>
        public Delegate CustomFunc { set; get; }

        /// <summary>
        /// 驗證該欄位是否重覆
        /// </summary>
        /// <returns></returns>
        HashSet<object> existSet = null;
        public bool IsExistValue(object value) {
            if(this.existSet == null) {
                existSet = new HashSet<object>();
            }

            if (existSet.Contains(value))
            {
                return true; 
            }

            this.existSet.Add(value);
            return false;
        }
        /// <summary>
        /// 如何宣告與使用，利用委派宣告，就不用定義全域的泛型
        /// </summary>
        private void Sample()
        {
            //宣告
            ExcelColumnValid a = new ExcelColumnValid()
            {
                CustomFunc = new Func<string, bool>(s =>
                {
                    return "1".Equals(s);
                })
            };

            //使用
            a.CustomFunc.DynamicInvoke("0");
        }
    }

}
