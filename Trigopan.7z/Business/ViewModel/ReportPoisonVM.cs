﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Trigopan.Business.ViewModel
{
    public class ReportPoisonVM
    {
        /// <summary>
        /// 入庫日期
        /// </summary>
        public DateTime FindDate { set; get; }

        /// <summary>
        /// 品項
        /// </summary>
        public Guid SuppliesSerialNo { set; get; }


    }
}