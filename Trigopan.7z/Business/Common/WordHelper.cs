﻿//==================================================================================
// Program        : Word Helper 
// Description    : Word Helper 使用Open Source的NPOI元件，可匯出Word
// Copyright      : Copyright (c) Dimerco Corportion . All Rights Reserved. 
// Author         : Kristi
// Version        : 2016年11月9日
// Update History : 
//==================================================================================
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using NPOI.XWPF.UserModel;
using System.Text.RegularExpressions;

namespace Utility.Common
{
    /// <summary>NOPIv2.2僅支援.docx</summary>
    public class WordHelper
    {
        XWPFDocument doc;    //Word主檔
        public WordHelper(string templatePath)
        {
            //開啟Excel Template
            using (FileStream fs = new FileStream(templatePath, FileMode.Open, FileAccess.ReadWrite))
            {
                doc = new XWPFDocument(fs);
            }
        }
        public WordHelper(Stream stream)
        {
            doc = new XWPFDocument(stream);
        }

        /// <summary>
        /// 設定資料至word
        /// </summary>
        /// <param name="nv"></param>
        /// <param name="szTemplatePath"></param>
        /// <param name="szSavePath"></param>
        /// <returns></returns>
        public WordHelper DataToWord(Dictionary<string, object> nv)
        {
            this.ReplaceParagraphs(nv, doc.Paragraphs);//段落內文中取代
            if (doc.Tables.Count > 0)//若內含表格物件須再取代
            {
                this.ReplaceTables(nv, doc.Tables);//在表格內搜尋取代
            }
            return this;
        }

        /// <summary>
        /// 記錄至檔案路徑
        /// </summary>
        /// <param name="savePath"></param>
        public void SaveToFile(string savePath)
        {
            using (FileStream file = new FileStream(savePath, FileMode.Create))
            {
                doc.Write(file);
            }
        }

        /// <summary>
        /// 記錄檔案且MemoryStream
        /// </summary>
        /// <returns></returns>
        public MemoryStream SaveToStream()
        {
            MemoryStream ms = null;

            using (MemoryStream stream = new MemoryStream())
            {
                doc.Write(stream);
                ms = new MemoryStream(stream.ToArray());
            }
            return ms;
        }

        /// <summary>逐段落取代內文</summary>
        /// <param name="nv">資料來源</param>
        /// <param name="liParagraphs">WORD_段落集合</param>
        private void ReplaceParagraphs(Dictionary<string, object> nv, IList<XWPFParagraph> liParagraphs)
        {
            foreach (XWPFParagraph p in liParagraphs)
            {
                ReplaceTxt(nv, p);
            }
        }
        /// <summary>逐資料表於其表格(Cell)中段落取代內文</summary>
        /// <param name="nv"></param>
        /// <param name="liTable"></param>
        private void ReplaceTables(Dictionary<string, object> nv, IList<XWPFTable> liTable)
        {
            foreach (XWPFTable t in liTable)
            {
                foreach (XWPFTableRow r in t.Rows)
                {
                    foreach (XWPFTableCell c in r.GetTableCells())
                    {
                        this.ReplaceParagraphs(nv, c.Paragraphs);//段落內文中取代
                        if (c.Tables.Count > 0)//若內含表格物件須再取代
                        {
                            this.ReplaceTables(nv, c.Tables);//在表格內搜尋取代
                        }
                    }
                }
            }
        }
        /// <summary>將段落中文字取代</summary>
        /// <param name="nv"資料來源</param>
        /// <param name="p">WORD_段落</param>
        private void ReplaceTxt(Dictionary<string, object> nv, XWPFParagraph p)
        {
            if (!p.IsEmpty)
            {
                //將整段文字取出
                string szTxt = p.ParagraphText;
                //使用正則式找出有 ${x} 的文字 從nv找出x的值取代之
                string m_pattern = @"\$\{(.+?)\}";
                Regex reg = new Regex(m_pattern, RegexOptions.Compiled);
                foreach (Match match in reg.Matches(szTxt))
                {
                    if (match.Success)//有找到 ${x}的字眼
                    {
                        //match.Groups[1].Value:x
                        string nvKey = match.Groups[1].Value;
                        if (nv.Any(x => x.Key == nvKey)) //來源中有找到該KEY時Replace
                        {
                            //match.Value:${x}
                            string m_szValue = nv[nvKey].ToString();
                            if(m_szValue.Contains("\r\n"))//有多行內容
                            {
                                string[] szSingleText = m_szValue.Split(new string[] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries);
                                p.ReplaceText(match.Value, szSingleText[0]);//第一行的值取代${x}
                                //第二行後值 [ 跳行 + 第二行後值]
                                for (int i = 1; i < szSingleText.Length; i++)
                                {
                                    XWPFRun run = p.CreateRun();
                                    run.AddCarriageReturn();//跳行
                                    run.SetText(szSingleText[i]);//填值
                                }
                            }
                            else//單行文字
                            {
                                p.ReplaceText(match.Value, m_szValue);
                            }
                        }
                        else //沒有設定值 Replace成空白
                        {
                            p.ReplaceText(match.Value, string.Empty);
                        }
                    }
                }
            }
        }
    }
}
