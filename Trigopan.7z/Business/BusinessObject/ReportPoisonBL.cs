﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using Trigopan.Business.ViewModel;
using Trigopan.Data.DataAccess.DAO;
using Trigopan.Data.DataAccess.Register;
using Trigopan.Data.DataAccess;
using Utility.Common;
using Test;

namespace Trigopan.Business.BusinessObject
{
    public class ReportPoisonBL
    {
        public MemoryStream OnReport(ReportPoisonVM vm)
        {

            DateTime sDate =  Convert.ToDateTime(vm.FindDate.ToString("yyyy/MM") + "/01");
            DateTime nextMonthDate = vm.FindDate.AddMonths(1);
            DateTime eDate = new DateTime(nextMonthDate.Year, nextMonthDate.Month, 1);

            ReportPoisonDAO dao = DaoFactory.GetInstance<ReportPoisonDAO>();
            List<ReportPoisonEntity> dataList = dao.FindReportList(eDate, sDate, vm.SuppliesSerialNo);

            //品項代號轉群組，一個品項一個WORD
            Dictionary<string, List<ReportPoisonEntity>> supMap = dataList
                                                                    .GroupBy(d => d.Supplies_Cname)
                                                                    .ToDictionary(k => k.Key, v => v.ToList());

            //Stream templeteStream = Resource.Word;
            Stream templeteStream = null;
            WordHelper wordHelper = new WordHelper(templeteStream);
            ZipHelper zipHelper = new ZipHelper();

            foreach (string suppliesCname in supMap.Keys)
            {
                //將查詢資料轉為Dictionary的格式
                Dictionary<string, object> m_nv = this.GetNvByDs(vm, supMap[suppliesCname]);

                //設定轉出-寫入至zip
                string fileName = suppliesCname + ".docx";
                Stream wordReport = wordHelper
                                        .DataToWord(m_nv)
                                        .SaveToStream();
                zipHelper.AddFile(fileName, wordReport);

            }

            return zipHelper.Zip();
        }



        /// <summary>將DataTable OR ORM OBJ Set To WordTag Mapping</summary>
        /// <param name="INVEST_CHECK_BE"></param>
        /// <returns></returns>
        private Dictionary<string, object> GetNvByDs(ReportPoisonVM vm, List<ReportPoisonEntity> pListDataRow)
        {
            //m_nv [string]: 範本檔內x}的x ；[object]:  範本檔內x}要取代的值
            Dictionary<string, object> m_nv = new Dictionary<string, object>();

            //查詢條件年月
            m_nv.Add("AP_Y", (vm.FindDate.Year - 1911).ToString());                           //放畫面條件
            //查詢條件年月
            m_nv.Add("AP_M", vm.FindDate.ToString("MM"));                          //放畫面條件
            //品項中文品名
            m_nv.Add("SUPPLIES_CNAME", pListDataRow[0].Supplies_Cname);          //"SUL.SUPPLIES_CNAME"
            //品項中文品名
            m_nv.Add("SUPPLIES_FNAME", pListDataRow[0].Supplies_Fname);          //"SUL.SUPPLIES_FNAME"
            //列管編號
            m_nv.Add("TUBE_NO", pListDataRow[0].Tube_No);                        //"SUL.TUBE_NO"
            //管制編號
            m_nv.Add("CONTROL_NO", pListDataRow[0].Control_No);                  //"SUL.CONTROL_NO"
            //品項許可證字號
            m_nv.Add("LICENSE_NO", pListDataRow[0].License_No);                  //"SUL.LICENSE_NO"
            //上月月底庫存量
            m_nv.Add("LAST_MON_AMT", pListDataRow[0].Last_Mon_Amt);                  //"SUL.LICENSE_NO"
            //,DENSITY					--密度				--數量*密度  
            //SUPPLIES_CNAME}吡啶 (SUPPLIES_FNAME}Pyridine)

            //結餘量:由上月月底數量逐筆計算。
            decimal ewAmt = Convert.ToDecimal(pListDataRow[0].Last_Mon_Amt);

            for (int i = 1; i <= pListDataRow.Count; i++)
            {
                int j = i - 1;
                //欄位資料
                DateTime ewhDate = pListDataRow[j].Ewh_Date;
                string ewhType = pListDataRow[j].Ewh_Type;
                string iEwhAmt = pListDataRow[j].I_Ewh_Amt;
                string uEwhAmt = pListDataRow[j].U_Ewh_Amt;
                string fEwhAmt = pListDataRow[j].F_Ewh_Amt;
                string supFname = pListDataRow[j].Sup_Fname;
                string corpAllowNo = pListDataRow[j].Corp_Allow_No;

                m_nv.Add("EM" + i, ewhDate.ToString("MM"));
                m_nv.Add("ED" + i, ewhDate.ToString("dd"));

                #region 依類型決定使用量位置
                if (ewhType.StartsWith("1"))
                {
                    m_nv.Add("I" + i, iEwhAmt);
                    //入庫++
                    ewAmt = ewAmt + Convert.ToDecimal(iEwhAmt);
                }
                else if (ewhType.StartsWith("2"))
                {
                    m_nv.Add("U" + i, uEwhAmt);
                    //出庫使用++
                    ewAmt = ewAmt - Convert.ToDecimal(uEwhAmt);
                }
                else if (ewhType.StartsWith("3"))
                {
                    m_nv.Add("F" + i, fEwhAmt);
                    //退貨報廢使用++
                    ewAmt = ewAmt - Convert.ToDecimal(fEwhAmt);
                }
                #endregion 依類型決定使用量位置

                //結餘量
                m_nv.Add("EW" + i, ewAmt.ToString());

                //公司及廠場名稱(須先建上下游)
                m_nv.Add("C" + i, supFname);

                //許可證字號/登記號碼/核可號碼/第四類備查文號/國外廠商地址
                m_nv.Add("AL" + i, corpAllowNo);
            }



            return m_nv;
        }
    }
}