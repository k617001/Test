﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Trigopan.Controllers
{
    public class ReportPoison : Controller
    {
        //
        // GET: /ReportPoison/

        public ActionResult Index()
        {
            return View();
        }

    }
}
