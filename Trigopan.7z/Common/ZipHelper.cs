﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using ICSharpCode.SharpZipLib.Zip;

namespace Test
{
    public class ZipHelper
    {
        Dictionary<string, Stream> fileMap = new Dictionary<string, Stream>();

        /// <summary>
        /// 新增檔案
        /// </summary>
        /// <param name="name"></param>
        /// <param name="stream"></param>
        /// <returns></returns>
        public ZipHelper AddFile(string name, Stream stream)
        {
            string mapName = this.SetName(name);
            fileMap.Add(mapName, stream);
            return this;
        }

        /// <summary>
        /// 重覆檔案時自動編碼
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        private string SetName(string name)
        {
            //取得檔名副檔名
            int lastIdx = name.LastIndexOf(".");
            string mainName = name.Substring(0, lastIdx);
            string exName = name.Substring(lastIdx);

            string fileName = name;
            int idx = 1;
            while (fileMap.ContainsKey(fileName))
            {
                fileName = mainName + "_" + idx + exName;
                idx++;
            }

            return fileName;
        }

        /// <summary>
        /// 壓縮至memoryStream
        /// </summary>
        /// <returns></returns>
        public MemoryStream Zip()
        {
            MemoryStream outputStream = new MemoryStream();
            ZipOutputStream zip = new ZipOutputStream(outputStream);
            zip.SetLevel(9); // 0 - store only to 9 - means best compression
            foreach (string fileName in fileMap.Keys)
            {
                ZipEntry entry = new ZipEntry(fileName);
                entry.DateTime = DateTime.Now;
                zip.PutNextEntry(entry);

                Stream file = fileMap[fileName];
                int readLength;
                byte[] buffer = new byte[4096];
                do
                {
                    readLength = file.Read(buffer, 0, buffer.Length);
                    if (readLength > 0)
                    {
                        zip.Write(buffer, 0, readLength);
                    }
                } while (readLength > 0);
            }



            return outputStream;
        }

        /// <summary>
        /// 壓縮至檔案
        /// </summary>
        /// <param name="path"></param>
        public void ZipToPath(string path)
        {
            MemoryStream ms = this.Zip();
            using (FileStream outStream = File.OpenWrite(path))
            {
                ms.WriteTo(outStream);
                outStream.Flush();
            }
        }

        /// <summary>
        /// 測試用
        /// </summary>
        private void Test()
        {
            string[] filenames = Directory.GetFiles("D:/zipTest");
            using (ZipOutputStream s = new ZipOutputStream(File.Create("d:/zzzzzzzz.zip")))
            {
                s.SetLevel(9); // 0 - store only to 9 - means best compression
                byte[] buffer = new byte[4096];
                foreach (string file in filenames)
                {
                    ZipEntry entry = new ZipEntry(Path.GetFileName(file));
                    entry.DateTime = DateTime.Now;
                    s.PutNextEntry(entry);
                    using (FileStream fs = File.OpenRead(file))
                    {
                        int sourceBytes;
                        do
                        {
                            sourceBytes = fs.Read(buffer, 0, buffer.Length);
                            s.Write(buffer, 0, sourceBytes);
                        } while (sourceBytes > 0);
                    }
                }
                s.Finish();
                s.Close();
            }
        }
    }
}
