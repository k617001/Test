﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeGenerator.Src.LoadSetting
{
    public class SettingVO
    {
        public SettingVO()
        {
            this.ColumnVOs = new List<SettingColumnVO>();
        }

        /// <summary>
        /// 專案根目錄
        /// </summary>
        public string ProjectRootPath { set; get; }

        /// <summary>
        /// 專案名稱
        /// </summary>
        public string ProjectName { set; get; }

        /// <summary>
        /// 屬性
        /// </summary>
        public string Attribute { set; get; }

        /// <summary>
        /// 名稱
        /// </summary>
        public string CodeName { set; get; }

        /// <summary>
        /// 註解
        /// </summary>
        public string CodeComment { set; get; }

        /// <summary>
        /// 欄位設定
        /// </summary>
        public List<SettingColumnVO> ColumnVOs { set; get; }
    }
}
