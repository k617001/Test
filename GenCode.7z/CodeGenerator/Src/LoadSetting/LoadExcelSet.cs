﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CommonUtil.Helper.ExcelHelper;
using NPOI.SS.UserModel;

namespace CodeGenerator.Src.LoadSetting
{
    public class LoadExcelSet
    {
        string projectName;
        string projectPath;
        public LoadExcelSet(string projectName, string projectPath)
        {
            this.projectName = projectName;
            this.projectPath = projectPath;
        }

        public List<SettingVO> Action(string path)
        {
            ExcelReaderHelper readExlHelper = new ExcelReaderHelper();
            IWorkbook wk = readExlHelper.SetWorkBook(path);
            int sheets = wk.NumberOfSheets;

            List<SettingVO> settingVOs = new List<SettingVO>();
            for (int i = 0; i < sheets; i++ )
            {
                ISheet sheet = wk.GetSheetAt(i);
                readExlHelper.SetSheet(sheet);

                //抓欄位
                SettingVO vo = GetVO(readExlHelper);
                settingVOs.Add(vo);

            }
            return settingVOs;
        }

        private SettingVO GetVO(ExcelReaderHelper readExlHelper)
        {
            SettingVO vo = new SettingVO();

            vo.ProjectName = this.projectName;
            vo.ProjectRootPath = this.projectPath;

            //抓header
            readExlHelper.SetRowCellIndex(0, 1);
            vo.Attribute = readExlHelper.GetRowValueString();
            vo.CodeName = readExlHelper.GetRowValueString();
            vo.CodeComment = readExlHelper.GetRowValueString();
            vo.ColumnVOs = this.GetColumnVO(readExlHelper);

            return vo;
        }

        private List<SettingColumnVO> GetColumnVO(ExcelReaderHelper readExlHelper)
        {
            readExlHelper.SetRowCellIndex(6, 0);

            List<SettingColumnVO> list = new List<SettingColumnVO>();

            while (!string.IsNullOrEmpty(readExlHelper.GetCellValueString()))
            {
                readExlHelper.SetCellIndex(0);


                SettingColumnVO vo = new SettingColumnVO();
                vo.No = Convert.ToInt32(readExlHelper.GetCellValueString());
                vo.EntityName = readExlHelper.GetCellValueString();
                vo.ViewName = readExlHelper.GetCellValueString();
                vo.ColumnType = readExlHelper.GetCellValueString();
                vo.ColumnCommand = readExlHelper.GetCellValueString();
                vo.ViewComponent = readExlHelper.GetCellValueString();
                vo.ViewCommand = readExlHelper.GetCellValueString();
                vo.SQLColumnCondiction = readExlHelper.GetCellValueString();
                vo.IsViewShow = "1".Equals(readExlHelper.GetCellValueString());
                vo.IsViewRequired = "1".Equals(readExlHelper.GetCellValueString());
                vo.ViewLength = "1".Equals(readExlHelper.GetCellValueString());
                vo.InitCode = readExlHelper.GetCellValueString();

                list.Add(vo);
                readExlHelper.NextRow();
            }

            return list;
        }
    }
}
