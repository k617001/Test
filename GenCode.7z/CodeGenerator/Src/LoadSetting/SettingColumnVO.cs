﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeGenerator.Src.LoadSetting
{
    public class SettingColumnVO
    {
        public int No { set; get; }
        public string EntityName { set; get; }
        public string ViewName { set; get; }
        /// <summary>
        /// 欄位型態
        /// </summary>
        public string ColumnType { set; get; }
        /// <summary>
        /// 欄位註解
        /// </summary>
        public string ColumnCommand { set; get; }
        /// <summary>
        /// 畫面元件
        /// </summary>
        public string ViewComponent { set; get; }
        /// <summary>
        /// 畫面顯示註解
        /// </summary>
        public string ViewCommand { set; get; }
        /// <summary>
        /// 條件SQL
        /// </summary>
        public string SQLColumnCondiction { set; get; }
        /// <summary>
        /// 是否顯示欄位
        /// </summary>
        public bool IsViewShow { set; get; }
        /// <summary>
        /// 是否必填
        /// </summary>
        public bool IsViewRequired { set; get; }
        /// <summary>
        /// 長度
        /// </summary>
        public bool ViewLength { set; get; }

        /// <summary>
        /// 預設的Code
        /// </summary>
        public string InitCode { set; get; }

    }
}
