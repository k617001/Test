﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CodeGenerator.Src.LoadSetting;
using System.IO;

namespace CodeGenerator.Src.baseClazz
{
	public class CodeBase
	{
        protected SettingVO setVO = null;
        public CodeBase(SettingVO setVO)
        {
            this.setVO = setVO;
        }


        protected void StringToFile(string path, string content)
        {
            string filename = Path.GetFileName(path);

            string fileDirPath = path.Replace(filename, "");

            StringToFile(fileDirPath, filename, content);
        }
        protected void StringToFile(string path, string fileName, string content)
        {
            Directory.CreateDirectory(path);
            using (StreamWriter sw = new StreamWriter(path + fileName))
            {
                sw.Write(content);
            }
        }
	}
}
