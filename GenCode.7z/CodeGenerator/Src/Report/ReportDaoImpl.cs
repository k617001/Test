﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CodeGenerator.Src.LoadSetting;
using CodeGenerator.Src.baseClazz;

namespace CodeGenerator.Src.Report
{
    public class ReportDaoImpl : CodeBase
    {
        string path = string.Empty;
        public ReportDaoImpl(SettingVO setVO)
            : base(setVO)
        {
            path = setVO.ProjectRootPath
                + setVO.ProjectName + ".Data/"
                + "Impl/"
                + setVO.CodeName + "DaoImpl.cs";
        }

        public void Action()
        {
            string code = @"
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace " + setVO.ProjectName + @".Data.DataAcess.DaoImpl
{
    public class " + setVO.CodeName + @"DaoImpl : BaseImpl, " + setVO.CodeName + @"DAO
    {
        public void PageResult() {
            
        }
    }
}

";

            base.StringToFile(path, code);
        }

        private string GetCondiction()
        {
            StringBuilder code = new StringBuilder();
            foreach (SettingColumnVO columnVO in base.setVO.ColumnVOs)
            {
                code.Append(this.Componet(columnVO));
            }

            return code.ToString();
        }

        public string Componet(SettingColumnVO columnVO)
        {
            string code = string.Empty;
            string type = columnVO.ColumnType;
            string idName = @" id=""" + columnVO.ViewName + @""" name=""" + columnVO.ViewName + @"""";

            if ("Guid".Equals(columnVO.ColumnType))
            {
                code = @"
                if(!Guid.Emply.Equals(" + columnVO.EntityName + @")) 
                {
                    condiction.Append(" + columnVO.SQLColumnCondiction + @");
                    paras.add("" + columnVO.EntityName + @"", dto." + columnVO.EntityName + @");
                }
";
            }

            return code;
        }
    }
}
