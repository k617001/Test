﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CodeGenerator.Src.LoadSetting;
using CodeGenerator.Src.baseClazz;

namespace CodeGenerator.Src.Report
{
    public class ReportDAO : CodeBase
    {
        string path = string.Empty;
        public ReportDAO(SettingVO setVO)
            : base(setVO)
        {
            path = setVO.ProjectRootPath
                + setVO.ProjectName + ".Data/"
                + "DAO/"
                + setVO.CodeName + "DaoImpl.cs";
        }



        public void Action()
        {
            string code = @"
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace " + setVO.ProjectName + @".Data.DataAcess.DAO
{
    public interface " + setVO.CodeName + @"DAO
    {
       
    }
}

";

            base.StringToFile(path, code);
        }
    }
}
