﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CodeGenerator.Src.LoadSetting;

namespace CodeGenerator.Src.Report
{
    public class ReportAction
    {
        public void Action(SettingVO setVO)
        {
            (new ReportController(setVO)).Action();
            (new ReportView(setVO)).Action();

            (new ReprotBL(setVO)).Action();
            (new ReportVM(setVO)).Action();

            (new ReportDTO(setVO)).Action();
            (new ReportDAO(setVO)).Action();
            (new ReportDaoImpl(setVO)).Action();
        }
    }
}
