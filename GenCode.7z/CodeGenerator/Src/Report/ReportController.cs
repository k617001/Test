﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CodeGenerator.Src.LoadSetting;
using CodeGenerator.Src.baseClazz;

namespace CodeGenerator.Src.Report
{
    public class ReportController : CodeBase
    {
        string path = string.Empty;
        public ReportController(SettingVO setVO)
            : base(setVO)
        {
            path = setVO.ProjectRootPath
                + setVO.ProjectName + "/"
                + "Controllers/"
                + setVO.CodeName + "Controller.cs";
        }

        public void Action()
        {
            string code = @"
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ZTestMVC.Controllers
{
    public class "+setVO.CodeName+@"Controller : Controller
    {
        public ActionResult Index()
        {
            " + setVO.CodeName + @"BL bl = BLFactory.Instanct(" + setVO.CodeName + @"BL);

            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = ""Your app description page."";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = ""Your contact page."";

            return View();
        }
    }
}

";

            base.StringToFile(path, code);
        }
    }
}
