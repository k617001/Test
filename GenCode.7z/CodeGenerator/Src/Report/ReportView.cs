﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CodeGenerator.Src.LoadSetting;
using CodeGenerator.Src.baseClazz;

namespace CodeGenerator.Src.Report
{
    public class ReportView : CodeBase
    {
        string path = string.Empty;
        public ReportView(SettingVO setVO) : base(setVO)
        {
            path = setVO.ProjectRootPath
                + setVO.ProjectName + "/"
                + "View/"
                + setVO.CodeName + ".cshtml";
        }

        public void Action()
        {
            string code = @"
@{
    ViewBag.Title = ""Index"";
}
@model ZTestMVC.Models.DemoVM
<h2>Index</h2>
<script src=""https://code.jquery.com/jquery-2.2.4.js""></script>

" + GetColumnCode() + @"

";

            base.StringToFile(path, code);
        }

        public string GetColumnCode()
        {
            StringBuilder code = new StringBuilder();
            foreach (SettingColumnVO columnVO in base.setVO.ColumnVOs)
            {
                code.Append(this.Componet(columnVO));
            }

            return code.ToString();
        }

        public string Componet(SettingColumnVO columnVO)
        {
            string code = string.Empty;
            string type = columnVO.ColumnType;
            string idName = @" id=""" + columnVO.ViewName + @""" name=""" + columnVO.ViewName + @"""";
            if ("select".Equals(type))
            {
                code = @"

<select " + idName + @" ></select>
";
            }
            else if ("hidden".Equals(type))
            {
                code = @"

<input type=""hidden"" " + idName + @">
";
            }
            else if ("text".Equals(type))
            {
                code = @"

<input type=""text"" " + idName + @">
";
            }
            else if ("number".Equals(type))
            {
                code = @"

<input type=""number"" " + idName + @">
";
            }
            else if ("textarea".Equals(type))
            {
                code = @"

<textarea rows=""4"" cols=""50"" " + idName + @"></textarea>
";
            }
            return code;
        }
    }
}
