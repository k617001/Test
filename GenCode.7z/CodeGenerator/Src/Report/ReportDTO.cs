﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CodeGenerator.Src.LoadSetting;
using CodeGenerator.Src.baseClazz;

namespace CodeGenerator.Src.Report
{
    public class ReportDTO : CodeBase
    {
        string path = string.Empty;
        public ReportDTO(SettingVO setVO)
            : base(setVO)
        {
            path = setVO.ProjectRootPath
                + setVO.ProjectName + ".Data/"
                + "DTO/"
                + setVO.CodeName + "DTO.cs";
        }

        public void Action()
        {
            string code = @"
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace "+setVO.ProjectName+@".Data.DataAccess.DTO
{
    public class " + setVO.CodeName + @"DTO
    {
       " + GetAttrCode() + @"
    }
}

";

            base.StringToFile(path, code);
        }



        private string GetAttrCode()
        {
            StringBuilder code = new StringBuilder();
            foreach (SettingColumnVO columnVO in base.setVO.ColumnVOs)
            {
                string attrCode = @"
        /// <summary>
        /// " + columnVO.ColumnCommand + @"
        /// </summary>
        public " + columnVO.ColumnType + @" " + columnVO.EntityName + @" { get; set; }

";
                code.Append(attrCode);
            }

            return code.ToString();
        }
    }
}
