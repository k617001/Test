﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NPOI.SS.UserModel;
using System.IO;
using NPOI.HSSF.UserModel;
using NPOI.XSSF.UserModel;

namespace CommonUtil.Helper.ExcelHelper
{

    public class BaseExcel
    {
        protected IWorkbook wk = null;
        protected ISheet sheet = null;

        protected int rowIndex = 0;
        protected int cellIndex = 0;



        /// <summary>
        /// 設定WorkBook
        /// </summary>
        /// <param name="stream"></param>
        /// <returns></returns>
        public IWorkbook SetWorkBook(string filePath)
        {
            using (FileStream fileStream = new FileStream(filePath, FileMode.Open, FileAccess.ReadWrite))
            {
                return SetWorkBook(fileStream);
            }

        }

        /// <summary>
        /// 設定WorkBook
        /// </summary>
        /// <param name="stream"></param>
        /// <returns></returns>
        public IWorkbook SetWorkBook(Stream stream)
        {
            try
            {
                this.wk = new XSSFWorkbook(stream);
            }
            catch (Exception e)
            {
                this.wk = new HSSFWorkbook(stream);
            }
            return this.wk;
        }

        public IWorkbook GetWorkBook()
        {
            return this.wk;
        }

        /// <summary>
        /// 設定sheet
        /// </summary>
        /// <param name="sheet"></param>
        public void SetSheet(ISheet sheet)
        {
            this.sheet = sheet;
        }

        /// <summary>
        /// 取得sheet
        /// </summary>
        /// <param name="sheet"></param>
        public ISheet GetSheet()
        {
            return this.sheet;
        }

        /// <summary>
        /// 設定Row位置
        /// </summary>
        /// <param name="rowIndex"></param>
        public void SetRowIndex(int rowIndex)
        {
            this.rowIndex = rowIndex;
        }

        /// <summary>
        /// 設定cell位置
        /// </summary>
        /// <param name="cellIndex"></param>
        public void SetCellIndex(int cellIndex)
        {
            this.cellIndex = cellIndex;
        }


        /// <summary>
        /// 設定row和cell位置
        /// </summary>
        /// <param name="cellIndex"></param>
        public void SetRowCellIndex(int rowIndex, int cellIndex)
        {
            this.rowIndex = rowIndex;
            this.cellIndex = cellIndex;
        }

        /// <summary>
        /// 取得目前row index
        /// </summary>
        /// <returns></returns>
        public int GetRowIndex()
        {
            return this.rowIndex;
        }

        /// <summary>
        /// 取得目前cell index
        /// </summary>
        /// <returns></returns>
        public int GetCellIndex()
        {
            return this.cellIndex;
        }

        /// <summary>
        /// 下一列
        /// </summary>
        public void NextRow()
        {
            this.rowIndex++;
            this.cellIndex = 0;
        }
        /// <summary>
        /// 下一個cell
        /// </summary>
        public void NextCell()
        {
            this.cellIndex++;
            this.rowIndex = 0;
        }

        /// <summary>
        /// 取得cell物件
        /// </summary>
        /// <returns></returns>
        public ICell GetCell()
        {
            ICell cell = GetRow().GetCell(this.cellIndex);
            if (cell == null)
            {
                cell = GetRow().CreateCell(this.cellIndex);
            }

            return cell;
        }

        /// <summary>
        /// 取得row物件
        /// </summary>
        /// <returns></returns>
        public IRow GetRow()
        {
            IRow row = this.sheet.GetRow(this.rowIndex);
            if(row == null) {
                row = this.sheet.CreateRow(this.rowIndex);
            }

            return row;
        }
    }
}
