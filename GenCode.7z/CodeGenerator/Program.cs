﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CodeGenerator.Src.LoadSetting;
using CodeGenerator.Src.Report;

namespace CodeGenerator
{
    public class Program
    {
        public static void Main(string[] args)
        {
            string projectName = "AAA";
            string projectPath = @"D:\Test\Gencode\";
            string settingExcelPath = @"D:\Test\GenCode\Setting.xlsx";

            LoadExcelSet load = new LoadExcelSet(projectName, projectPath);
            List<SettingVO> settingVOs = load.Action(settingExcelPath);

            foreach(SettingVO setVO in settingVOs) {

                (new ReportAction()).Action(setVO);
            }
        }
    }
}
