﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using RestAlert.Properties;

namespace RestAlert
{
    public partial class Form1 : Form
    {
        int workMinute = 20;
        int restMinute = 5;

        public Form1()
        {


            InitializeComponent();


            this.WorkM.Text = this.workMinute.ToString();
            this.RestM.Text = this.restMinute.ToString();

            this.StartBtn.Enabled = true;
            this.StopBtn.Enabled = false;

            //時間
            nowTime.Start();

            Notity();
        }

        NotifyIcon notifyIcon;
        public void Notity()
        {
            notifyIcon = new NotifyIcon();
            notifyIcon.BalloonTipText = "**眼睛休息計時器**";
            notifyIcon.Text = "**眼睛休息計時器**";
            notifyIcon.Icon = Resources.Rotate8;
            notifyIcon.Click += (sender, e) =>
            {
                notifyIcon.Visible = false;
                this.ShowInTaskbar = true;
                this.Show();
            };
        }

        /// <summary>
        /// 縮小鍵
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            //this.ShowInTaskbar = false;
            this.Hide();
            notifyIcon.Visible = true;
            //notifyIcon.ShowBalloonTip(1000, "這是標題", "這是內文", ToolTipIcon.Info);
            
        }

        /// <summary>
        /// 開始鍵
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void StartBtn_Click(object sender, EventArgs e)
        {

            this.workMinute = Convert.ToInt32(this.WorkM.Text);
            this.restMinute = Convert.ToInt32(this.RestM.Text);

            this.StartBtn.Enabled = false;
            this.StopBtn.Enabled = true;

            //開始時設定工作時間,與下次休息的時間
            setTimerTime(workMinute);
            NextTimeShow.Text = "工作至..." + DateTime.Now.AddMinutes(workMinute).ToString("HH:mm:ss");
        }

        /// <summary>
        /// 停止鍵
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void StopBtn_Click(object sender, EventArgs e)
        {
            this.StartBtn.Enabled = true;
            this.StopBtn.Enabled = false;
            this.timer1.Stop();
        }

        /// <summary>
        /// 時間觸發
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// 
        int status = 1;
        int waitMinute = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (DateTime.Now.Hour < Convert.ToInt16(this.sHour.Text))
            {
                this.NextTimeShow.Text = "--";
                return;
            }
            if (DateTime.Now.Hour > Convert.ToInt16(this.eHour.Text))
            {
                this.NextTimeShow.Text = "--";
                return;
            }


            string title = null;
            string nextStatusTitle = "";
            if (status == 1)
            {
                waitMinute = this.restMinute;
                status = 0;
                title = "讓眼睛休息 " + waitMinute + " 分鐘吧!!!!";
                nextStatusTitle = "休息";
            }
            else if (status == 0)
            {
                waitMinute = this.workMinute;
                status = 1;
                title = "開始工作了... " + waitMinute + " 分鐘";
                nextStatusTitle = "工作";
            }

            string nextTime = DateTime.Now.AddMinutes(waitMinute).ToString("HH:mm:ss");
            MessageBox.Show(title + ",下次通知時間:" + nextTime);
            setTimerTime(waitMinute);

            NextTimeShow.Text = "" + nextStatusTitle + "至..." + nextTime;

        }

        /// <summary>
        /// 顯示目前時間的時間觸發
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void nowTime_Tick(object sender, EventArgs e)
        {
            TimeShow.Text = DateTime.Now.ToString("HH:mm:ss");
        }

        /// <summary>
        /// 設定時間
        /// </summary>
        /// <param name="minute"></param>
        private void setTimerTime(int minute)
        {
            this.timer1.Interval = 1000 * 60 * minute;
            this.timer1.Enabled = true;
            this.timer1.Start();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}
