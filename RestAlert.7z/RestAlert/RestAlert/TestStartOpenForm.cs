﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace RestAlert
{
    public partial class TestStartOpenForm : Form
    {
        public TestStartOpenForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WinShow f = new WinShow("");
            f.Show();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

        }
    }
}
