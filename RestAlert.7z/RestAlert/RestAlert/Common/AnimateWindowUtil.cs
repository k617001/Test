﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

namespace RestAlert.Common
{
    public class AnimateWindowUtil
    {
        public static void Open(string message)
        {
            new WinShow(message).Show();
        }
    }
}
