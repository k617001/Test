﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace RestAlert
{
    public partial class WinShow : Form
    {

        public WinShow(string message)
        {
            InitializeComponent();
            this.Time.Text = DateTime.Now.ToString("HH:mm:ss");
            this.Msg.Text = message;
            //ShowWindow();


            this.StartPosition = FormStartPosition.Manual;
            int x = Screen.PrimaryScreen.WorkingArea.Right - this.Width;
            int y = Screen.PrimaryScreen.WorkingArea.Bottom - this.Height;
            this.Location = new Point(x, y);

            setTimerTime(3);
        }


        /// <summary>
        /// 設定時間
        /// </summary>
        /// <param name="minute"></param>
        private void setTimerTime(int sec)
        {
            this.timer1.Interval = 1000 * sec;
            this.timer1.Enabled = true;
            this.timer1.Start();
        }

        /// <summary>
        /// 時間觸發
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void timer1_Tick(object sender, EventArgs e)
        {
            this.timer1.Stop();
            this.Close();
        }
    }
}
