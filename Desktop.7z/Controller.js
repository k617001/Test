
	$.fn.Controller = function(actionSet) {
		
		  //清空欄位 
		this.columnClean = function () {
		  $(':input',this.selector)
			 .not(':button, :submit, :reset, :hidden')
			 .val(null)
			 .removeAttr('checked')
			 .removeAttr('selected');
		}
		
		//把form組成json
		this.formJson =	function() {
			var formArray = this.serializeArray(),
				indexed_array = [];
			$.map(formArray, function(n, i){
				indexed_array[n['name']] = n['value'];
			});
			return indexed_array;
		}		
		
		//ajax呼叫，統一錯誤訊息json格式的方法
		this.ajaxCall = function(setting) {
		  return $.ajax(setting)
				  .fail(function(ros) {
					var failMsgData = JSON.parse(ros.responseText);
					alert(failMsgData);
				  }); 
		}
			
		//欄位驗証的設定
		this.validate();
		$.extend($.validator.messages, {
			required: "此欄位必填!!",
			remote: "Please fix this field.",
			email: "請填寫正確的E-mail格式",
			url: "Please enter a valid URL.",
			date: "Please enter a valid date.",
			dateISO: "Please enter a valid date ( ISO ).",
			number: "Please enter a valid number.",
			digits: "Please enter only digits.",
			creditcard: "Please enter a valid credit card number.",
			equalTo: "Please enter the same value again.",
			maxlength: $.validator.format( "Please enter no more than {0} characters." ),
			minlength: $.validator.format( "Please enter at least {0} characters." ),
			rangelength: $.validator.format( "Please enter a value between {0} and {1} characters long." ),
			range: $.validator.format( "Please enter a value between {0} and {1}." ),
			max: $.validator.format( "Please enter a value less than or equal to {0}." ),
			min: $.validator.format( "Please enter a value greater than or equal to {0}." )
		});
		
		
		//呼叫action
		if(actionSet.action) {
			actionSet.action(this);
		}
		
		return this;
	}