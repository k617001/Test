﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WinFormTest.Common;
using System.Threading;
using System.Drawing.Drawing2D;

namespace WinFormTest
{
    public partial class StartTest : Form
    {

        Color[] colors = new Color[]
        {
            Color.Red,
            Color.Blue,
            Color.Coral
        };

        Map map = null;
        public StartTest()
        {
            InitializeComponent();

            map = new Map(this.panel, this.colors, this.allSource, this.thisSource);
        }

        private void start_Click(object sender, EventArgs e)
        {
            map.Draw();
        }
    }

    public class Map
    {
        Color[] colors = null;
        int SIZE = 20;

        Label[,] mapArray = null;
        Panel panel = null;
        int sizeX = 0;
        int sizeY = 0;

        Label source = null;
        Label nowSource = null;

        public Map(Panel panel, Color[] colors, Label source, Label nowSource)
        {
            this.sizeX = panel.Size.Width;
            this.sizeY = panel.Size.Height;
            this.panel = panel;
            this.colors = colors;
            this.source = source;
            this.nowSource = nowSource;
            Draw();
        }

        /// <summary>
        /// 位置陣列
        /// </summary>
        public Label[,] GetMapArray { get { return this.mapArray; } }

        /// <summary>
        /// 畫圖
        /// </summary>
        /// <param name="panel"></param>
        /// <param name="sizeX"></param>
        /// <param name="sizeY"></param>
        public void Draw()
        {
            panel.Controls.Clear();
            //取得可塞入格子的panel
            panel.Size = new Size(this.sizeX, this.sizeY);
            int xSize = (int)(sizeX / SIZE);
            int ySize = (int)(sizeY / SIZE);

            this.mapArray = new Label[xSize, ySize];
            for (int x = 0; x < xSize; x++)
            {
                for (int y = 0; y < ySize; y++)
                {
                    Label square = this.SetSquare(x, y);
                    panel.Controls.Add(square);
                    this.mapArray[x, y] = square;
                }
            }
        }

        /// <summary>
        /// 設定格子樣式
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <returns></returns>
        Random rnd = new Random(Guid.NewGuid().GetHashCode());
        private Label SetSquare(int x, int y)
        {
            //格子樣式
            Label square = new Label();
            square.BorderStyle = BorderStyle.Fixed3D;
            square.Size = new Size(SIZE, SIZE);
            square.Location = new Point(x * SIZE, y * SIZE);
            square.Name = "p_" + x + "_" + y;

            //亂數取得顏色
            int strIdx = rnd.Next(0, colors.Length);
            square.BackColor = colors[strIdx];

            //設定點選的觸發
            square.Click += new System.EventHandler(this.label_Click);

            return square;
        }
        
        /// <summary>
        /// 點選格子時的觸發
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        HashSet<Label> hideLabels = new HashSet<Label>();
        private void label_Click(object sender, EventArgs e)
        {
            //每次清空要隱藏的格子
            hideLabels.Clear();
            Label thisLabel = (Label)sender;

            //判斷下一格的遞迴
            NextLabel(thisLabel);
            
            //只記錄一個格子時不隱藏
            if(hideLabels.Count == 1) {
                return;
            }

            //隱藏格子
            foreach(Label hideLabel in hideLabels) {
                hideLabel.Visible = false;
            }
            
            //格子往下掉
            this.DownLabel();

            //計算分數
            this.SetSource(hideLabels.Count);

            //檢查是否已結束
        }

        /// <summary>
        /// 計算分數
        /// </summary>
        /// <param name="count"></param>
        private void SetSource(int count)
        {
            int baseSource = Convert.ToInt32(this.source.Text);
            int addSource = (1 + count) * count;

            this.nowSource.Text = addSource.ToString();
            this.source.Text = (baseSource + addSource).ToString();
        }

        /// <summary>
        /// 往下掉，分類後再組合
        /// </summary>
        private void DownLabel()
        {
            int maxX = GetMapArray.GetLength(0);
            int maxY = GetMapArray.GetLength(1);

            List<Label> hidLabels = new List<Label>();
            List<Label> showLabels = new List<Label>();

            //往下掉
            for (int x = 0; x < maxX; x++)
            {
                for (int y = 0; y < maxY; y++)
                {
                    Label square = this.mapArray[x, y];
                    if (square.Visible)
                    {
                        showLabels.Add(square);
                    }
                    else
                    {
                        hidLabels.Add(square);
                    }
                }

                hidLabels.AddRange(showLabels);
                int idxY = 0;
                foreach (Label hidLabel in hidLabels)
                {

                    mapArray[x, idxY] = hidLabel;
                    hidLabel.Location = new Point(x * SIZE, idxY * SIZE);
                    hidLabel.Name = "p_" + x + "_" + idxY;
                    idxY++;
                }

                hidLabels.Clear();
                showLabels.Clear();
            }

            //往左靠
            for (int y = 0; y < maxY; y++)
            {
                for (int x = 0; x < maxX; x++)
                {
                    Label square = this.mapArray[x, y];
                    if (square.Visible)
                    {
                        showLabels.Add(square);
                    }
                    else
                    {
                        hidLabels.Add(square);
                    }
                }

                showLabels.AddRange(hidLabels);
                int idxX = 0;
                foreach (Label showLabel in showLabels)
                {

                    mapArray[idxX, y] = showLabel;
                    showLabel.Location = new Point(idxX * SIZE, y * SIZE);
                    showLabel.Name = "p_" + idxX + "_" + y;
                    idxX++;
                }

                hidLabels.Clear();
                showLabels.Clear();
            }

            //重繪panel
            this.panel.Refresh();
        }



        /// <summary>
        /// 下一個格子
        /// </summary>
        /// <param name="thisLabel"></param>
        private void NextLabel(Label thisLabel)
        {
            hideLabels.Add(thisLabel);
            string[] names = thisLabel.Name.Split('_');
            int x = Convert.ToInt32(names[1]);
            int y = Convert.ToInt32(names[2]);

            //走遞迴檢查,上下左右的格子
            int left = x - 1;
            int right = x + 1;
            int up = y + 1;
            int down = y - 1;

            if (left >= 0)
            {
                this.HideLabel(GetMapArray[left, y], thisLabel);
            }
            if (right < GetMapArray.GetLength(0))
            {
                this.HideLabel(GetMapArray[right, y], thisLabel);
            }
            if (down >= 0)
            {
                this.HideLabel(GetMapArray[x, down], thisLabel);
            }
            if (up < GetMapArray.GetLength(1))
            {
                this.HideLabel(GetMapArray[x, up], thisLabel);
            }
        }

        /// <summary>
        /// 決定要走下一格的遞迴
        /// </summary>
        /// <param name="thisLabel"></param>
        /// <param name="baseLabel"></param>
        private void HideLabel(Label thisLabel, Label baseLabel)
        {
            if (!baseLabel.BackColor.ToString().Equals(thisLabel.BackColor.ToString()) //不一樣的顏色不處理
                || hideLabels.Contains(thisLabel) //要隱藏的格子不處理
                || !thisLabel.Visible //已隱藏的格子不處理
                )
            {
                return;
            }

            NextLabel(thisLabel);
        }
    }

}
