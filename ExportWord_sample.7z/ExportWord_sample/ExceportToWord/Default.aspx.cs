﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.IO;
using MySql.Data.MySqlClient;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        

    }


    
    protected void Unnamed1_Click(object sender, EventArgs e)
    {
        #region 查詢資料   
        /*MySqlConnection 有加入MQSQL.DATA.DLL*/
        string connString = "server=127.0.0.1;uid=root;Password=1234;database=trigopan";
        MySqlConnection myconn = new MySqlConnection(connString);
        MySqlDataAdapter adapter;
        DataTable myTable = new DataTable();
        try
        {
            myconn.Open();
        }
        catch { 
            //MessageBox.Show("mysql 連線失敗");
        }

        adapter = new MySqlDataAdapter(this.GetWordSQL(this.YM.Text), myconn);
        adapter.Fill(myTable);
        
        #endregion 查詢資料

        #region 依品項代號轉群組，一個品項一個WORD
        var grouped = myTable.AsEnumerable().GroupBy(d => new
                        {
                            //品項中文名稱
                            SUPPLIES_CNAME = d.Field<string>("SUPPLIES_CNAME")
                        });
                    
        #endregion 依品項代號轉群組，一個品項一個WORD
        //Word 元件【】
        Utility.Common.WordHelper word = new Utility.Common.WordHelper();


        foreach (var gp in grouped)
        {
            var Rows = gp.AsEnumerable().OrderBy(x => x.Field<DateTime>("EWH_DATE")).ThenBy(s => s.Field<string>("EWH_TYPE"));

            //一個品項處理
            foreach(DataRow m_Dr in Rows)
            {
                //將DataSet轉為Dictionary的格式
                Dictionary<string, object> m_nv = this.GetNvByDs(Rows.ToList());

                //Word範本路徑
                string m_szTemplateName = "範本Word.docx";
                string m_szTemplatePath = @"D:\2.Trigopan工作區\trigopan\ExportWord_sample\ExceportToWord\WordTemplate\";
                string m_szTemplatePathAndFileName = m_szTemplatePath + m_szTemplateName;
                //string m_szTemplatePath = @"D:\WordTemplate\", _szTemplateName);


                if (!File.Exists(m_szTemplatePathAndFileName))
                {
                    //base.Messager("", "", "轉出報表範本已遺失，無法產出報表!!", MessageType.Alert);
                    return;
                }
                //執行匯出Word
                //轉出路徑
                string m_szExportPath = @"D:\";

                //設定品項的檔名
                string m_szExportFileName = Rows.ToList()[0]["SUPPLIES_CNAME"] + ".docx";
                word.ToWord(m_nv, m_szTemplatePathAndFileName, m_szExportPath + m_szExportFileName);
                //word.ToWord(m_nv, m_szTemplatePath, Path.Combine(m_szExportPath, m_szExportFileName));
            }
        }
    }

    /// <summary>將DataTable OR ORM OBJ Set To WordTag Mapping</summary>
    /// <param name="INVEST_CHECK_BE"></param>
    /// <returns></returns>
    private Dictionary<string, object> GetNvByDs(List<DataRow> pListDataRow)
    {
        //m_nv [string]: 範本檔內x}的x ；[object]:  範本檔內x}要取代的值
        Dictionary<string, object> m_nv = new Dictionary<string, object>();


        #region 幫忙改寫一下Client端條件

        string ConditopnYM = this.YM.Text;


        #endregion 幫忙改寫一下Client端條件


        //查詢條件年月
        m_nv.Add("AP_Y", (Convert.ToInt16(ConditopnYM.Substring(0,4))-1911).ToString());                           //放畫面條件
        //查詢條件年月
        m_nv.Add("AP_M", ConditopnYM.Substring(4, 2));                          //放畫面條件
        //品項中文品名
        m_nv.Add("SUPPLIES_CNAME", pListDataRow[0]["SUPPLIES_CNAME"]);          //"SUL.SUPPLIES_CNAME"
        //品項中文品名
        m_nv.Add("SUPPLIES_FNAME", pListDataRow[0]["SUPPLIES_FNAME"]);          //"SUL.SUPPLIES_FNAME"
        //列管編號
        m_nv.Add("TUBE_NO", pListDataRow[0]["TUBE_NO"]);                        //"SUL.TUBE_NO"
        //管制編號
        m_nv.Add("CONTROL_NO", pListDataRow[0]["CONTROL_NO"]);                  //"SUL.CONTROL_NO"
        //品項許可證字號
        m_nv.Add("LICENSE_NO", pListDataRow[0]["LICENSE_NO"]);                  //"SUL.LICENSE_NO"
        //上月月底庫存量
        m_nv.Add("LAST_MON_AMT", pListDataRow[0]["LAST_MON_AMT"]);                  //"SUL.LICENSE_NO"
        //,DENSITY					--密度				--數量*密度  
        //SUPPLIES_CNAME}吡啶 (SUPPLIES_FNAME}Pyridine)

        //結餘量:由上月月底數量逐筆計算。
        decimal EW_AMT = Convert.ToDecimal(pListDataRow[0]["LAST_MON_AMT"]);

        for (int i = 1; i <= pListDataRow.Count; i++)
        {
            int j = i - 1;
            //月份
            m_nv.Add("EM" + i.ToString(), Convert.ToDateTime(pListDataRow[j]["EWH_DATE"]).ToString("MM"));
            m_nv.Add("ED" + i.ToString() , Convert.ToDateTime(pListDataRow[j]["EWH_DATE"]).ToString("dd"));

            #region 依類型決定使用量位置
            if(pListDataRow[j]["EWH_TYPE"].ToString().StartsWith("1"))
            {
                m_nv.Add("I" + i.ToString() , pListDataRow[j]["I_EWH_AMT"].ToString());
                //入庫++
                EW_AMT = EW_AMT + Convert.ToDecimal(pListDataRow[j]["I_EWH_AMT"]);
            }
            else if (pListDataRow[j]["EWH_TYPE"].ToString().StartsWith("2"))
            {
                m_nv.Add("U" + i.ToString() , pListDataRow[j]["U_EWH_AMT"].ToString());
                //出庫使用++
                EW_AMT = EW_AMT - Convert.ToDecimal(pListDataRow[j]["U_EWH_AMT"]);
            }
            else if (pListDataRow[j]["EWH_TYPE"].ToString().StartsWith("3"))
            {
                m_nv.Add("F" + i.ToString() , pListDataRow[j]["F_EWH_AMT"].ToString());
                //退貨報廢使用++
                EW_AMT = EW_AMT - Convert.ToDecimal(pListDataRow[j]["F_EWH_AMT"]);
            }
            #endregion 依類型決定使用量位置

            //結餘量
            m_nv.Add("EW" + i.ToString() , EW_AMT.ToString());

            //公司及廠場名稱(須先建上下游)
            m_nv.Add("C" + i.ToString() , pListDataRow[j]["SUP_FNAME"].ToString());

            //許可證字號/登記號碼/核可號碼/第四類備查文號/國外廠商地址
            m_nv.Add("AL" + i.ToString() , pListDataRow[j]["CORP_ALLOW_NO"].ToString());
        }
        
       
        
        return m_nv;
    }

    private string GetWordSQL(string ym) 
    {
        //當月的一號
        DateTime m_thisMonthFirstDate = Convert.ToDateTime(ym.Substring(0, 4) + "/" + ym.Substring(4, 2) + "/01");
        //當月的最後一天
        DateTime m_thisMonthEndDate = new DateTime(m_thisMonthFirstDate.AddMonths(1).Year, m_thisMonthFirstDate.AddMonths(1).Month, 1).AddDays(-1);
        //上個月的最後一天
        DateTime m_LastMonthEndDate = m_thisMonthFirstDate.AddDays(m_thisMonthFirstDate.Day * -1);
        
        string sql11 = "set @thisMonthFirstDate = '"+m_thisMonthFirstDate.ToString("yyyy/MM/dd hh:mm:dd")+"';";
        sql11 = "set @thisMonthEndDate = '"+m_thisMonthEndDate.ToString("yyyy/MM/dd hh:mm:dd")+"';";
        sql11 = "set @LastMonthEndDate = '"+m_LastMonthEndDate.ToString("yyyy/MM/dd hh:mm:dd")+"';";

        string sql  =
        @"
        SELECT A.EWH_DATE,A.EWH_TYPE
        ,SUL.SUPPLIES_CNAME																#--品項中文品名
        ,SUL.SUPPLIES_FNAME																#--品項中文品名
        ,SUL.TUBE_NO																		#--列管編號
        ,SUL.CONTROL_NO																	#--管制編號
        ,SUL.LICENSE_NO																	#--品項許可證字號
        ,SUL.DENSITY																		#--密度
        ,ROUND((CASE WHEN LM_AMT.BOOK_REM_AMT IS NULL THEN 0 ELSE LM_AMT.BOOK_REM_AMT END) * SUL.DENSITY,2) AS LAST_MON_AMT			#--上月月底庫存量(數量*密度)
        ,SUP.SUP_FNAME																		#--廠商英文名稱
        ,SUP.CORP_ALLOW_NO																#--廠商許可證號
        ,ROUND(A.I_EWH_AMT*SUL.DENSITY,2) AS I_EWH_AMT							#--異動量(數量*密度)(入庫交易)
        ,ROUND(A.U_EWH_AMT*SUL.DENSITY,2) AS U_EWH_AMT							#--異動量(數量*密度)
        ,ROUND(A.F_EWH_AMT*SUL.DENSITY,2) AS F_EWH_AMT							#--異動量(數量*密度)

        FROM (
	        #整理出一天、一種交易類型、一個供應商，出一筆就好，省的處理反向交易呈現面怪怪的問題
	        SELECT WT.EWH_DATE
	        ,SSD.SUPPLIES_SerialNo													#品項(WORD區分兩家供應商)
	        ,SSD.SUP_SerialNo																	#供應商
	        ,(CASE WHEN WT.EWH_TYPE IN ('1','1D') THEN '1-I' WHEN WT.EWH_TYPE IN ('2','2D') THEN '2-U' ELSE '3-F' END) EWH_TYPE
	        #--異動量(數量*密度)(入庫交易)，有考慮反向交易
	        ,SUM(CASE WHEN WT.EWH_TYPE = '1' THEN WT.EWH_AMT WHEN WT.EWH_TYPE = '1D' THEN -WT.EWH_AMT ELSE 0 END) AS I_EWH_AMT												#--入庫異動量(數量*密度)
	        ,SUM(CASE WHEN WT.EWH_TYPE = '2' THEN WT.EWH_AMT WHEN WT.EWH_TYPE = '2D' THEN -WT.EWH_AMT ELSE 0 END) AS U_EWH_AMT												#--使用異動量(數量*密度)
	        ,SUM(CASE WHEN WT.EWH_TYPE IN ('3','4') THEN WT.EWH_AMT WHEN WT.EWH_TYPE IN ('3D','4D') THEN -WT.EWH_AMT ELSE 0 END) AS F_EWH_AMT							#--報廢退貨異動量(數量*密度)
	        FROM WAREHOURSE_TRD WT
	        LEFT JOIN SUPPLIES_STOCK_DTL SSD ON SSD.SerialNo = WT.SUPPLIES_STOCK_SerialNo
	        WHERE WT.EWH_DATE >= '2017/12/01'												#--查詢當月起日【畫面提條件為年月】
	        AND WT.EWH_DATE <= '2017/12/31'													#--查詢當月迄日【畫面提條件為年月】
	        GROUP BY WT.EWH_DATE,SSD.SUPPLIES_SerialNo,SSD.SUP_SerialNo,(CASE WHEN WT.EWH_TYPE IN ('1','1D') THEN 'I' WHEN WT.EWH_TYPE IN ('2','2D') THEN 'U' ELSE 'F' END)
        ) A
        LEFT JOIN SUPPLIES SUL ON SUL.SerialNo = A.SUPPLIES_SerialNo
        LEFT JOIN SUPPLIER_INFO SUP ON SUP.SerialNo = A.SUP_SerialNo
        LEFT JOIN (
	        #抓出上個月月底相同品項的月底庫存使用BATCH記錄檔
	        SELECT SUPPLIES_SerialNo
	        ,SUM(BOOK_REM_AMT) AS BOOK_REM_AMT			#--帳列庫存
	        FROM SUPPLIES_STOCK_DTL_BATCH
	        WHERE WORK_DATE = '2017/11/30'				#上月月底日曆日
	        GROUP BY SUPPLIES_SerialNo
        ) LM_AMT ON LM_AMT.SUPPLIES_SerialNo = SUL.SerialNo
        WHERE TUBE_NO <> ''																		#--列管編號不為空白表示為毒化物
        #畫面條件
        #AND SUPPLIES_NO = 'XXX'																#--畫面下拉的毒化物品項代號【每個毒化物格是不同	】


        
        ";
        return sql;
    }
}